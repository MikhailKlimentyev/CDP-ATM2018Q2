/**
 * SentEmailPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/22/2018
 */

package com.epam.cdp.atm2018q2.m10.pages;

import org.openqa.selenium.By;

public class SentEmailPage extends GmailPage {
    private static final By EMAIL_HEADER_LOCATOR = By.xpath("//div[1][@class='y6']/span[@class='bog'][1]");

    public SentEmailPage() {
        super();
    }

    public String getHeaderText() {
        return driver.findElement(EMAIL_HEADER_LOCATOR).getAttribute("textContent");
    }
}
