/**
 * WebDriverSingleton.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/14/2018
 */

package com.epam.cdp.atm2018q2.m10.utils;

import org.openqa.selenium.WebDriver;

import java.util.concurrent.TimeUnit;

public class WebDriverSingleton {
    private static WebDriver instance;
    private static DriverType driverType;

    private WebDriverSingleton() {
        //block constructor
    }

    public static void setDriver(DriverType driverType) {
        WebDriverSingleton.driverType = driverType;
    }

    public static WebDriver getWebDriverInstance() {
        if (instance == null) {
            switch (driverType) {
                case CHROME:
                    instance = new ChromeDriverCreator().createWebDriver();
                    break;
                case FIREFOX:
                    instance = new FirefoxDriverCreator().createWebDriver();
                    break;
                case IE:
                    instance = new InternetExplorerDriverCreator().createWebDriver();
                    break;
                default:
                    instance = new ChromeDriverCreator().createWebDriver();
                    break;
            }
            instance.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
            instance.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            instance.manage().window().maximize();
            return instance;
        } else {
            return instance;
        }
    }

    public static void kill() {
        if (instance != null) {
            try {
                instance.quit();
            } catch (Exception e) {
                System.err.println("Cannot kill browser");
            } finally {
                instance = null;
            }
        }
    }
}
