package com.epam.cdp.atm2018q2.m10.utils;

public enum DriverType {
    FIREFOX, CHROME, IE
}
