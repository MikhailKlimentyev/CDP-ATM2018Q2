/**
 * ChromeDriverCreator.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 8/11/2018
 */

package com.epam.cdp.atm2018q2.m10.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ChromeDriverCreator implements WebDriverCreator {
    public WebDriver createWebDriver() {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
        return new ChromeDriver();
    }
}
