/**
 * TestRunner.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 8/19/2018
 */

package com.epam.cdp.atm2018q2.m10.utils;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(strict = true,
        features = "src/test/resources/cucumber_features/",
        plugin = {"json:target/cucumber-report.json", "html:target/cucumber-report"},
        glue = {"com.epam.cdp.atm2018q2.m10.stepdefs"}
//        tags = {"@AuthorizationTest", "@CheckDraftedEmailContentTest"}
)
public class TestRunner extends AbstractTestNGCucumberTests {
// some custom code stuff here
}

