/**
 * OperatorIdentifier.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 9/1/2018
 */

package com.epam.cdp.atm2018q2.m10.regex;

import com.epam.cdp.atm2018q2.m10.utils.GlobalConstants;

import java.util.regex.Pattern;

public class OperatorIdentifier {

    public boolean isVelcom(String phoneNumber){
        String content = phoneNumber;
        String pattern = GlobalConstants.getVelcomPattern();
        boolean isMatch = Pattern.matches(pattern, content);
        return isMatch;
    }

    public boolean isMts(String phoneNumber){
        String content = phoneNumber;
        String pattern = GlobalConstants.getMtsPattern();
        boolean isMatch = Pattern.matches(pattern, content);
        return isMatch;
    }

    public boolean isLife(String phoneNumber){
        String content = phoneNumber;
        String pattern = GlobalConstants.getLifePattern();
        boolean isMatch = Pattern.matches(pattern, content);
        return isMatch;
    }
}
