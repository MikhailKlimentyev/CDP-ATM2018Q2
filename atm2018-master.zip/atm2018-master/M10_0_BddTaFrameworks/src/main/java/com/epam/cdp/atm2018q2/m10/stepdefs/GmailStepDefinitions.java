/**
 * GmailStepDefinitions.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 8/19/2018
 */

package com.epam.cdp.atm2018q2.m10.stepdefs;

import com.epam.cdp.atm2018q2.m10.bo.Accounts;
import com.epam.cdp.atm2018q2.m10.bo.Email;
import com.epam.cdp.atm2018q2.m10.pages.*;
import com.epam.cdp.atm2018q2.m10.utils.GlobalConstants;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.testng.Assert;

public class GmailStepDefinitions {
    LoginPage loginPage;
    GmailPage gmailPage;
    AccountPage accountPage;
    EmailPage emailPage;
    DraftEmailPage draftEmailPage;
    PasswordPage passwordPage;

    @Given("^I opened [Gg][Mm][Aa][Ii][Ll].com (?:site|website)")
    public void iOpenedGmailWebSite() {
        loginPage = new LoginPage().open();
    }

    @And("^I open account icon$")
    public void iOpenAccountIcon() {
        accountPage = gmailPage.accountIconClick();
    }

    @Then("^Email label presents on the account icon$")
    public void emailLabelPresentsOnTheAccountIcon() {
        Assert.assertTrue(accountPage.isElementPresent(accountPage.getEmailOnAccountIconLocator()), "Email label does not present on the account icon.");
    }

    @Then("^Sign Out button presents on the account icon$")
    public void signOutButtonPresentsOnTheAccountIcon() {
        Assert.assertTrue(accountPage.isElementPresent(accountPage.getSignOutButtonLocator()), "'Sign out' button does not present on the account icon.");
    }

    @And("^I compose email$")
    public void iComposeEmail() {
        Email email = new Email(GlobalConstants.getToInputText(), GlobalConstants.getSubjectInputText(), GlobalConstants.getBodyInputText());
        emailPage = gmailPage.composeButtonClick().popOutButtonClick().toInputSendKeys(email.getToInputText()).subjectInputSendKeys(email.getSubjectInputText()).
                bodyInputSendKeys(email.getBodyInputText());
    }

    @And("^I close email$")
    public void iCloseEmail() {
        emailPage.closeButtonClick();
    }

    @And("^I open last drafted email$")
    public void iOpenLastDraftedEmail() {
        draftEmailPage = gmailPage.draftsIconClick().draftEmailCheckboxClick().draftLabelClick();
    }

    @Then("^'To' field's text of composed email equals to 'To' field's text of drafted email$")
    public void toFieldSTextOfComposedEmailEqualsToToFieldSTextOfDraftedEmail() {
        Assert.assertEquals(draftEmailPage.getToInputText(), GlobalConstants.getToNameSurname(), "'To' field's text of drafted email does not equal to 'To' field's text of composed email");
    }

    @When("^I login with valid credentials$")
    public void iLoginWithValidCredentials() {
        gmailPage = loginPage.fillLoginInput(Accounts.ACCOUNT_WITH_VALID_CREDENTIALS.getLogin()).nextButtonClick().
                fillPasswordInput(Accounts.ACCOUNT_WITH_VALID_CREDENTIALS.getPassword()).nextButtonClick();
    }

    @When("^I enter valid login$")
    public void iEnterValidLogin() {
        passwordPage = loginPage.fillLoginInput(Accounts.ACCOUNT_WITH_VALID_CREDENTIALS.getLogin()).nextButtonClick();
    }

    @And("I enter invalid ([\\w*, ])")
    public void iEnterInvalidPassword(String password) {
        passwordPage.fillPasswordInput(password).nextButtonClick();
    }

    @Then("^Wrong password notification appears$")
    public void wrongPasswordNotificationAppears() {
        Assert.assertTrue(passwordPage.isElementPresent(PasswordPage.getWrongPasswordNotificationLocator()), "Wrong password notification does not appear");
    }
}
