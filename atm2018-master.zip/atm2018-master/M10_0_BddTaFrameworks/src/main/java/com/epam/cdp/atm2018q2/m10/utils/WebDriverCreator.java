/**
 * WebDriverCreator.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 8/11/2018
 */

package com.epam.cdp.atm2018q2.m10.utils;

import org.openqa.selenium.WebDriver;

public interface WebDriverCreator {
    public WebDriver createWebDriver();
}
