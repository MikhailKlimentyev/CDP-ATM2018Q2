/**
 * EmailWithSmile.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 8/12/2018
 */

package com.epam.cdp.atm2018q2.m10.bo;

public class EmailWithCc extends EmailDecorator {
    private String ccInputText;

    public EmailWithCc(Email email, String ccInputText) {
        super(email);
        this.ccInputText = ccInputText;
    }

    public String getCcInputText() {
        return ccInputText;
    }
}
