/**
 * FirefoxDriverCreator.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 8/11/2018
 */

package com.epam.cdp.atm2018q2.m10.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FirefoxDriverCreator implements WebDriverCreator {
    public WebDriver createWebDriver() {
        System.setProperty("webdriver.gecko.driver", "src/main/resources/geckodriver.exe");
        return new FirefoxDriver();
    }
}
