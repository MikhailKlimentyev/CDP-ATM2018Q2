/**
 * ScenarioHooks.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 8/19/2018
 */

package com.epam.cdp.atm2018q2.m10.stepdefs;

import com.epam.cdp.atm2018q2.m10.utils.WebDriverSingleton;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class ScenarioHooks {
    @Before
    public void beforeScenario(){
    }

    @After
    public void afterScenario(){
        WebDriverSingleton.kill();
    }
}
