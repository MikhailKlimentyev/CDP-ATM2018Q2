/**
 * InternetExplorerDriverCreator.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 8/11/2018
 */

package com.epam.cdp.atm2018q2.m10.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class InternetExplorerDriverCreator implements WebDriverCreator {
    public WebDriver createWebDriver() {
        System.setProperty("webdriver.ie.driver", "src/main/resources/IEDriverServer.exe");
        return new InternetExplorerDriver();
    }
}
