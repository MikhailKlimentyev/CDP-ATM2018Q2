/**
 * IsMtsTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 9/1/2018
 */

package com.epam.cdp.atm2018q2.m10.tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class IsMtsTest extends BaseTest{

    @Test(groups = "Regex", dataProvider = "valuesForIsMtsGetStringReturnTrueTest")
    public void isMtsGetStringReturnTrueTest(String phoneNumber, String message) {
        boolean result = operatorIdentifier.isMts(phoneNumber);
        Assert.assertTrue(result, message);
    }

    @DataProvider(name = "valuesForIsMtsGetStringReturnTrueTest")
    public Object[][] valuesForIsMtsGetStringReturnTrueTest() {
        return new Object[][]{
                {new String("+375 29 223 45 67"), "Invalid result for +375 29 223 45 67"},
                {new String("+375(29)523-45-67"), "Invalid result for +375(29)523-45-67"},
                {new String("+375(29)723-45-67"), "Invalid result for +375(29)723-45-67"},
                {new String("+375(29)823-45-67"), "Invalid result for +375(29)823-45-67"},
                {new String("+375297234567"), "Invalid result for +375297234567"}
        };
    }

    @Test(groups = "Regex", dataProvider = "valuesForIsMtsGetStringReturnFalseTest")
    public void isMtsGetStringReturnFalseTest(String phoneNumber, String message) {
        boolean result = operatorIdentifier.isMts(phoneNumber);
        Assert.assertFalse(result, message);
    }

    @DataProvider(name = "valuesForIsMtsGetStringReturnFalseTest")
    public Object[][] valuesForIsMtsGetStringReturnFalseTest() {
        return new Object[][]{
                {new String("+375(29)123 45 67"), "Invalid result for +375(29)123 45 67"},
                {new String("+375(29)323 45 67"), "Invalid result for +375(29)323 45 67"},
                {new String("+375(29)623 45 67"), "Invalid result for +375(29)623 45 67"},
                {new String("+375(29)923 45 67"), "Invalid result for +375(29)923 45 67"},
                {new String("+375(44)123 45 67"), "Invalid result for +375(44)123 45 67"},
                {new String("+375 29 12 345 67"), "Invalid result for +375 29 12 345 67"},
                {new String("+375 29 12 345 67"), "Invalid result for +375 29 12 345 67"},
                {new String("+375 29 12 34 567"), "Invalid result for +375 29 12 34 567"},
                {new String("+375-29-123-45-67"), "Invalid result for +375-29-123-45-67"},
                {new String("+375291234567"), "Invalid result for +375291234567"},
                {new String("+375(29)1234567"), "Invalid result for +375(29)1234567"},
                {new String("+375(44)1234567"), "Invalid result for +375(44)1234567"},
                {new String("8(029)123 45 67"), "Invalid result for 8(029)123 45 67"},
                {new String("8-029-123-45-67"), "Invalid result for 8-029-123-45-67"},
                {new String("8(029)12 345 67"), "Invalid result for 8(029)12 345 67"},
                {new String("8(029)12 34 567"), "Invalid result for 8(029)12 34 567"},
                {new String("8(029)1234567"), "Invalid result for 8(029)1234567"},
                {new String("80291234567"), "Invalid result for 80291234567"},
                {new String("+375-25-123-45-67"), "Invalid result for +375-25-123-45-67"},
                {new String("+375251234567"), "Invalid result for +375251234567"},
                {new String("+375(25)1234567"), "Invalid result for +375(25)1234567"}
        };
    }
}
