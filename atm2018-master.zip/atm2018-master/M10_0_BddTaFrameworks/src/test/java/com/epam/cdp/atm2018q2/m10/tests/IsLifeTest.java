/**
 * IsLifeTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 9/2/2018
 */

package com.epam.cdp.atm2018q2.m10.tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class IsLifeTest extends BaseTest {
    @Test(groups = "Regex", dataProvider = "valuesForIsLifeGetStringReturnTrueTest")
    public void isLifeGetStringReturnTrueTest(String phoneNumber, String message) {
        boolean result = operatorIdentifier.isLife(phoneNumber);
        Assert.assertTrue(result, message);
    }

    @DataProvider(name = "valuesForIsLifeGetStringReturnTrueTest")
    public Object[][] valuesForIsLifeGetStringReturnTrueTest() {
        return new Object[][]{
                {new String("+375-25-123-45-67"), "Invalid result for +375-25-123-45-67"},
                {new String("+375251234567"), "Invalid result for +375251234567"},
                {new String("+375(25)1234567"), "Invalid result for +375(25)1234567"}
        };
    }

    @Test(groups = "Regex", dataProvider = "valuesForIsLifeGetStringReturnFalseTest")
    public void isLifeGetStringReturnFalseTest(String phoneNumber, String message) {
        boolean result = operatorIdentifier.isLife(phoneNumber);
        Assert.assertFalse(result, message);
    }

    @DataProvider(name = "valuesForIsLifeGetStringReturnFalseTest")
    public Object[][] valuesForIsLifeGetStringReturnFalseTest() {
        return new Object[][]{
                {new String("+375(29)123 45 67"), "Invalid result for +375(29)123 45 67"},
                {new String("+375(29)323 45 67"), "Invalid result for +375(29)323 45 67"},
                {new String("+375(29)623 45 67"), "Invalid result for +375(29)623 45 67"},
                {new String("+375(29)923 45 67"), "Invalid result for +375(29)923 45 67"},
                {new String("+375(44)123 45 67"), "Invalid result for +375(44)123 45 67"},
                {new String("+375 29 12 345 67"), "Invalid result for +375 29 12 345 67"},
                {new String("+375 29 12 345 67"), "Invalid result for +375 29 12 345 67"},
                {new String("+375 29 12 34 567"), "Invalid result for +375 29 12 34 567"},
                {new String("+375-29-123-45-67"), "Invalid result for +375-29-123-45-67"},
                {new String("+375291234567"), "Invalid result for +375291234567"},
                {new String("+375(29)1234567"), "Invalid result for +375(29)1234567"},
                {new String("+375(44)1234567"), "Invalid result for +375(44)1234567"},
                {new String("8(029)123 45 67"), "Invalid result for 8(029)123 45 67"},
                {new String("8-029-123-45-67"), "Invalid result for 8-029-123-45-67"},
                {new String("8(029)12 345 67"), "Invalid result for 8(029)12 345 67"},
                {new String("8(029)12 34 567"), "Invalid result for 8(029)12 34 567"},
                {new String("8(029)1234567"), "Invalid result for 8(029)1234567"},
                {new String("80291234567"), "Invalid result for 80291234567"},
                {new String("+375 29 223 45 67"), "Invalid result for +375 29 223 45 67"},
                {new String("+375(29)523-45-67"), "Invalid result for +375(29)523-45-67"},
                {new String("+375(29)723-45-67"), "Invalid result for +375(29)723-45-67"},
                {new String("+375(29)823-45-67"), "Invalid result for +375(29)823-45-67"},
                {new String("+375297234567"), "Invalid result for +375297234567"}
        };
    }
}
