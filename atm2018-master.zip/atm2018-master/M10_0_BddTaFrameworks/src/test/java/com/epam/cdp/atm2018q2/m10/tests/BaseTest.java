/**
 * BaseTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 9/1/2018
 */

package com.epam.cdp.atm2018q2.m10.tests;

import com.epam.cdp.atm2018q2.m10.regex.OperatorIdentifier;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public abstract class BaseTest {

    protected OperatorIdentifier operatorIdentifier;

    @BeforeClass(groups = "Regex")
    public void setUp() {
        operatorIdentifier = new OperatorIdentifier();
    }

    @AfterClass(groups = "Regex")
    public void tearDown() {
        operatorIdentifier = null;
    }

}
