/**
 * AuthorizationTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/28/2018
 */

package com.epam.cdp.atm2018q2.m09;

import com.epam.cdp.atm2018q2.m09.bo.Accounts;
import com.epam.cdp.atm2018q2.m09.pages.AccountPage;
import com.epam.cdp.atm2018q2.m09.pages.LoginPage;
import com.epam.cdp.atm2018q2.m09.utils.WebDriverSingleton;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

public class AuthorizationTest {

    @Test(description = "Email label presents on account icon after authorization")
    public void emailLabelPresentsOnAccountIconTest() {
        AccountPage accountPage = new LoginPage().open().fillLoginInput(Accounts.ACCOUNT_WITH_VALID_CREDENTIALS.getLogin()).nextButtonClick().fillPasswordInput(Accounts.ACCOUNT_WITH_VALID_CREDENTIALS.getPassword()).nextButtonClick().accountIconClick();
        Assert.assertTrue(accountPage.isElementPresent(accountPage.getEmailOnAccountIconLocator()), "Email label was not found on the account icon.");
    }

    @Test(description = "'Sign out' button presents on account icon after authorization")
    public void signOutButtonPresentsOnAccountIconTest() {
        AccountPage accountPage = new LoginPage().open().fillLoginInput(Accounts.ACCOUNT_WITH_VALID_CREDENTIALS.getLogin()).nextButtonClick().fillPasswordInput(Accounts.ACCOUNT_WITH_VALID_CREDENTIALS.getPassword()).nextButtonClick().accountIconClick();
        Assert.assertTrue(accountPage.isElementPresent(accountPage.getSignOutButtonLocator()), "'Sign out' button was not found on the account icon.");
    }

    @AfterMethod(description = "Close browser, kill webdriver")
    public void kill() {
        WebDriverSingleton.kill();
    }
}
