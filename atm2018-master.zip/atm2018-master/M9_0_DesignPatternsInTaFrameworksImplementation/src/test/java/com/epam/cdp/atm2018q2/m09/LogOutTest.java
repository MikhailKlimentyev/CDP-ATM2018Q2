/**
 * LogOutTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/28/2018
 */

package com.epam.cdp.atm2018q2.m09;

import com.epam.cdp.atm2018q2.m09.pages.LoginPage;
import com.epam.cdp.atm2018q2.m09.pages.PasswordPage;
import com.epam.cdp.atm2018q2.m09.utils.WebDriverSingleton;
import org.openqa.selenium.Alert;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import static com.epam.cdp.atm2018q2.m09.bo.Accounts.ACCOUNT_WITH_VALID_CREDENTIALS;

public class LogOutTest {

    @Test(description = "Log out")
    public void doLogOutTest() {
        PasswordPage passwordPage = new LoginPage().open().fillLoginInput(ACCOUNT_WITH_VALID_CREDENTIALS.getLogin()).nextButtonClick().
                fillPasswordInput(ACCOUNT_WITH_VALID_CREDENTIALS.getPassword()).nextButtonClick().accountIconClick().signOutButtonClick();
        if (passwordPage.isAlertPresent()) {
            Alert logOutConfirmation = WebDriverSingleton.getWebDriverInstance().switchTo().alert();
            logOutConfirmation.accept();
        }
        Assert.assertTrue(passwordPage.isElementPresent(passwordPage.getHeadingTextLocator()), "Sign out was not made");
    }

    @AfterMethod(description = "Close browser, kill webdriver")
    public void kill() {
        WebDriverSingleton.kill();
    }
}
