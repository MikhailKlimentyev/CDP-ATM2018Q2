/**
 * CheckDraftedEmailContentTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/28/2018
 */

package com.epam.cdp.atm2018q2.m09;

import com.epam.cdp.atm2018q2.m09.bo.Email;
import com.epam.cdp.atm2018q2.m09.bo.EmailWithAttachment;
import com.epam.cdp.atm2018q2.m09.bo.EmailWithCc;
import com.epam.cdp.atm2018q2.m09.pages.DraftEmailPage;
import com.epam.cdp.atm2018q2.m09.pages.DraftsPage;
import com.epam.cdp.atm2018q2.m09.pages.GmailPage;
import com.epam.cdp.atm2018q2.m09.pages.LoginPage;
import com.epam.cdp.atm2018q2.m09.utils.GlobalConstants;
import com.epam.cdp.atm2018q2.m09.utils.WebDriverSingleton;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.io.File;

import static com.epam.cdp.atm2018q2.m09.bo.Accounts.ACCOUNT_WITH_VALID_CREDENTIALS;

public class CheckDraftedEmailContentTest {

    @Test(description = "Compare 'To' field content of composed email and drafted email")
    public void checkToInputContentOfDraftedEmailTest() {
        Email email = new Email(GlobalConstants.getToInputText(), GlobalConstants.getSubjectInputText(), GlobalConstants.getBodyInputText());
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(ACCOUNT_WITH_VALID_CREDENTIALS.getLogin()).nextButtonClick().
                fillPasswordInput(ACCOUNT_WITH_VALID_CREDENTIALS.getPassword()).nextButtonClick().composeButtonClick().popOutButtonClick().
                toInputSendKeys(email.getToInputText()).subjectInputSendKeys(email.getSubjectInputText()).
                bodyInputSendKeys(email.getBodyInputText()).closeButtonClick();
        DraftEmailPage draftEmailPage = gmailPage.draftsIconClick().draftEmailCheckboxClick().draftLabelClick();
        Assert.assertEquals(draftEmailPage.getToInputText(), GlobalConstants.getToNameSurname(), "Text in 'To' field of drafted email is not valid");
    }

    @Test(description = "Compare 'Subject' field content of composed email and drafted email")
    public void checkSubjectInputContentOfDraftedEmailTest() {
        Email email = new Email(GlobalConstants.getToInputText(), GlobalConstants.getSubjectInputText(), GlobalConstants.getBodyInputText());
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(ACCOUNT_WITH_VALID_CREDENTIALS.getLogin()).nextButtonClick().
                fillPasswordInput(ACCOUNT_WITH_VALID_CREDENTIALS.getPassword()).nextButtonClick().composeButtonClick().popOutButtonClick().
                toInputSendKeys(email.getToInputText()).subjectInputSendKeys(email.getSubjectInputText()).
                bodyInputSendKeys(email.getBodyInputText()).closeButtonClick();
        DraftEmailPage draftEmailPage = gmailPage.draftsIconClick().draftEmailCheckboxClick().draftLabelClick();
        Assert.assertEquals(draftEmailPage.getSubjectInputText(), email.getSubjectInputText(), "Text in 'Subject' field of drafted email is not valid");
    }

    @Test(description = "Compare 'Body' field content of composed email and drafted email")
    public void checkBodyInputContentOfDraftedEmailTest() {
        Email email = new Email(GlobalConstants.getToInputText(), GlobalConstants.getSubjectInputText(), GlobalConstants.getBodyInputText());
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(ACCOUNT_WITH_VALID_CREDENTIALS.getLogin()).nextButtonClick().
                fillPasswordInput(ACCOUNT_WITH_VALID_CREDENTIALS.getPassword()).nextButtonClick().composeButtonClick().popOutButtonClick().
                toInputSendKeys(email.getToInputText()).subjectInputSendKeys(email.getSubjectInputText()).
                bodyInputSendKeys(email.getBodyInputText()).closeButtonClick();
        DraftEmailPage draftEmailPage = gmailPage.draftsIconClick().draftEmailCheckboxClick().draftLabelClick();
        Assert.assertEquals(draftEmailPage.getBodyInputText(), email.getBodyInputText(), "Text in 'Body' field of drafted email is not valid");
    }

    @Test(description = "Compare Header content of composed email and drafted email")
    public void checkHeaderContentOfDraftedEmailTest() {
        Email email = new Email(GlobalConstants.getToInputText(), GlobalConstants.getSubjectInputText(), GlobalConstants.getBodyInputText());
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(ACCOUNT_WITH_VALID_CREDENTIALS.getLogin()).nextButtonClick().
                fillPasswordInput(ACCOUNT_WITH_VALID_CREDENTIALS.getPassword()).nextButtonClick().composeButtonClick().popOutButtonClick().
                toInputSendKeys(email.getToInputText()).subjectInputSendKeys(email.getSubjectInputText()).
                bodyInputSendKeys(email.getBodyInputText()).closeButtonClick();
        DraftEmailPage draftEmailPage = gmailPage.draftsIconClick().draftEmailCheckboxClick().draftLabelClick();
        Assert.assertEquals(draftEmailPage.getHeaderText(), email.getSubjectInputText(), "Text of Header of drafted email is not valid");
    }

    @Test(description = "Add attachment to email, verify name of attached file in drafted email")
    public void checkAttachmentIsAddedToDraftedEmailTest() {
        Email email = new Email(GlobalConstants.getToInputText(), GlobalConstants.getSubjectInputText(), GlobalConstants.getBodyInputText());
        File file = new File(GlobalConstants.getFilePath());
        EmailWithAttachment emailWithAttachment = new EmailWithAttachment(email, file);
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(ACCOUNT_WITH_VALID_CREDENTIALS.getLogin()).nextButtonClick().
                fillPasswordInput(ACCOUNT_WITH_VALID_CREDENTIALS.getPassword()).nextButtonClick().composeButtonClick().popOutButtonClick().
                toInputSendKeys(email.getToInputText()).subjectInputSendKeys(email.getSubjectInputText()).
                bodyInputSendKeys(email.getBodyInputText()).attachFile(emailWithAttachment.getFile().getAbsolutePath()).closeButtonClick();
        DraftsPage draftsPage = gmailPage.draftsIconClick();
        Assert.assertEquals(draftsPage.getAttachedFileName(), GlobalConstants.getFileName(), "Attachment is not added.");
    }

    @Test(description = "Compare CC content of composed email and drafted email")
    public void checkCcContentOfDraftedEmailTest() {
        Email email = new Email(GlobalConstants.getToInputText(), GlobalConstants.getSubjectInputText(), GlobalConstants.getBodyInputText());
        EmailWithCc emailWithCc = new EmailWithCc(email, GlobalConstants.getCcInputText());
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(ACCOUNT_WITH_VALID_CREDENTIALS.getLogin()).nextButtonClick().
                fillPasswordInput(ACCOUNT_WITH_VALID_CREDENTIALS.getPassword()).nextButtonClick().composeButtonClick().popOutButtonClick().
                ccIconClick().toInputSendKeys(email.getToInputText()).ccInputSendKeys(emailWithCc.getCcInputText()).subjectInputSendKeys(email.getSubjectInputText()).
                bodyInputSendKeys(email.getBodyInputText()).closeButtonClick();
        DraftEmailPage draftEmailPage = gmailPage.draftsIconClick().draftEmailCheckboxClick().draftLabelClick();
        Assert.assertEquals(draftEmailPage.getCcText(), emailWithCc.getCcInputText(), "Text of CC of drafted email is not valid");
    }

    @AfterMethod(description = "Close browser, kill webdriver")
    public void kill() {
        WebDriverSingleton.kill();
    }
}
