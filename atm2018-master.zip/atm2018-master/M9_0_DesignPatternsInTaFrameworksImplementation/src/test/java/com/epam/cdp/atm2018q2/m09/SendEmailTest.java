/**
 * SendEmailTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/28/2018
 */

package com.epam.cdp.atm2018q2.m09;

import com.epam.cdp.atm2018q2.m09.bo.Email;
import com.epam.cdp.atm2018q2.m09.pages.GmailPage;
import com.epam.cdp.atm2018q2.m09.pages.LoginPage;
import com.epam.cdp.atm2018q2.m09.utils.GlobalConstants;
import com.epam.cdp.atm2018q2.m09.utils.WebDriverSingleton;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import static com.epam.cdp.atm2018q2.m09.bo.Accounts.ACCOUNT_WITH_VALID_CREDENTIALS;

public class SendEmailTest {

    @Test(description = "Send email, verify that drafted email's count is decreased after email sending.")
    public void verifyThatEmailDeletedFromDraftsAfterSending() throws InterruptedException {
        Email email = new Email(GlobalConstants.getToInputText(), GlobalConstants.getSubjectInputText(), GlobalConstants.getBodyInputText());
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(ACCOUNT_WITH_VALID_CREDENTIALS.getLogin()).nextButtonClick().
                fillPasswordInput(ACCOUNT_WITH_VALID_CREDENTIALS.getPassword()).nextButtonClick().composeButtonClick().popOutButtonClick().
                toInputSendKeys(email.getToInputText()).subjectInputSendKeys(email.getSubjectInputText()).
                bodyInputSendKeys(email.getBodyInputText()).closeButtonClick();
        int initialDraftsNumber = gmailPage.getDraftsNumber();
        gmailPage.draftsIconClick().draftEmailCheckboxClick().draftLabelClick().sendButtonClick();
        Thread.sleep(1000);
        int finalDraftsNumber = gmailPage.getDraftsNumber();
        Assert.assertEquals(finalDraftsNumber, initialDraftsNumber - 1, "Sent Email was not deleted from 'Drafts' folder");
    }

    @Test(description = "Send email, verify that sent email header equals to text inputted into email header")
    public void verifyThatSubjectOfSentEmailIsCorrectTest() throws InterruptedException {
        Email email = new Email(GlobalConstants.getToInputText(), GlobalConstants.getSubjectInputText(), GlobalConstants.getBodyInputText());
        String sentEmailHeader = new LoginPage().open().fillLoginInput(ACCOUNT_WITH_VALID_CREDENTIALS.getLogin()).nextButtonClick().
                fillPasswordInput(ACCOUNT_WITH_VALID_CREDENTIALS.getPassword()).nextButtonClick().composeButtonClick().popOutButtonClick().
                toInputSendKeys(email.getToInputText()).subjectInputSendKeys(email.getSubjectInputText()).
                bodyInputSendKeys(email.getBodyInputText()).closeButtonClick().draftsIconClick().
                draftEmailCheckboxClick().draftLabelClick().sendButtonClick().sentMailIconClick().getHeaderText();
        Assert.assertEquals(sentEmailHeader, email.getSubjectInputText(), "Email was not sent");
    }

    @AfterMethod(description = "Close browser, kill webdriver")
    public void kill() {
        WebDriverSingleton.kill();
    }
}
