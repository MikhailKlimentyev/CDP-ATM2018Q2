/**
 * DeleteSentEmailTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/29/2018
 */

package com.epam.cdp.atm2018q2.m09;

import com.epam.cdp.atm2018q2.m09.bo.Email;
import com.epam.cdp.atm2018q2.m09.pages.GmailPage;
import com.epam.cdp.atm2018q2.m09.pages.LoginPage;
import com.epam.cdp.atm2018q2.m09.utils.GlobalConstants;
import com.epam.cdp.atm2018q2.m09.utils.WebDriverSingleton;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import static com.epam.cdp.atm2018q2.m09.bo.Accounts.ACCOUNT_WITH_VALID_CREDENTIALS;


public class DeleteDraftEmailTest {
    @Test(description = "Delete email from Draft folder using JS context click, verify that Drafts count decreased")
    public void verifyThatDraftedEmailDeletedTest() {
        Email email = new Email(GlobalConstants.getToInputText(), GlobalConstants.getSubjectInputText(), GlobalConstants.getBodyInputText());
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(ACCOUNT_WITH_VALID_CREDENTIALS.getLogin()).nextButtonClick().
                fillPasswordInput(ACCOUNT_WITH_VALID_CREDENTIALS.getPassword()).nextButtonClick().composeButtonClick().popOutButtonClick().
                toInputSendKeys(email.getToInputText()).subjectInputSendKeys(email.getSubjectInputText()).
                bodyInputSendKeys(email.getBodyInputText()).closeButtonClick();
        int initialDraftsNumber = gmailPage.getDraftsNumber();
        System.out.println("DeleteDraftEmailTest\ninitialDraftsNumber: " + initialDraftsNumber);
        gmailPage.draftsIconClick().draftEmailCheckboxContextMenuCall();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        int finalDraftsNumber = gmailPage.getDraftsNumber();
        System.out.println("finalDraftsNumber: " + finalDraftsNumber);
        Assert.assertTrue(finalDraftsNumber == initialDraftsNumber - 1, "Email was not deleted from 'Drafts' folder");
    }

    @Test(description = "Move drafred emails to 'Trash' folder via drag and drop action, verify that Drafts count decreased")
    public void moveDrafredEmailsToTrashFolder() {
        Email email = new Email(GlobalConstants.getToInputText(), GlobalConstants.getSubjectInputText(), GlobalConstants.getBodyInputText());
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(ACCOUNT_WITH_VALID_CREDENTIALS.getLogin()).nextButtonClick().
                fillPasswordInput(ACCOUNT_WITH_VALID_CREDENTIALS.getPassword()).nextButtonClick();
        for (int i = 0; i < 3; i++) {
            gmailPage.composeButtonClick().popOutButtonClick().toInputSendKeys(email.getToInputText()).subjectInputSendKeys(email.getSubjectInputText()).
                    bodyInputSendKeys(email.getBodyInputText()).closeButtonClick();
        }
        int initialDraftsNumber = gmailPage.getDraftsNumber();
        System.out.println("DeleteDraftEmailTest\ninitialDraftsNumber: " + initialDraftsNumber);
        gmailPage.draftsIconClick().multiClickCheckboxes().openMoreDropDown().dragAndDropDraftedEmailsToTrashFolder();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        int finalDraftsNumber = gmailPage.getDraftsNumber();
        System.out.println("finalDraftsNumber: " + finalDraftsNumber);
        Assert.assertTrue(finalDraftsNumber == initialDraftsNumber - 3, "Email was not deleted from 'Drafts' folder");
    }

    @AfterMethod(description = "Close browser, kill webdriver")
    public void kill() {
        WebDriverSingleton.kill();
    }
}
