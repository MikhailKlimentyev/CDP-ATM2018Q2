/**
 * ComposeEmailTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/28/2018
 */

package com.epam.cdp.atm2018q2.m09;

import com.epam.cdp.atm2018q2.m09.bo.Email;
import com.epam.cdp.atm2018q2.m09.pages.GmailPage;
import com.epam.cdp.atm2018q2.m09.pages.LoginPage;
import com.epam.cdp.atm2018q2.m09.utils.GlobalConstants;
import com.epam.cdp.atm2018q2.m09.utils.WebDriverSingleton;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import static com.epam.cdp.atm2018q2.m09.bo.Accounts.ACCOUNT_WITH_VALID_CREDENTIALS;

public class ComposeEmailTest {

    @Test(description = "Compose Email, close Email without sending, verify that composed email presents in drafts folder")
    public void verifyThatComposedEmailSavedInDraftsFolderTest() {
        Email email = new Email(GlobalConstants.getToInputText(), GlobalConstants.getSubjectInputText(), GlobalConstants.getBodyInputText());
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(ACCOUNT_WITH_VALID_CREDENTIALS.getLogin()).nextButtonClick().fillPasswordInput(ACCOUNT_WITH_VALID_CREDENTIALS.getPassword()).nextButtonClick();
        int initialDraftsNumber = gmailPage.getDraftsNumber();
        System.out.println("composeEmailTest\ninitialDraftsNumber: " + initialDraftsNumber);
        gmailPage.composeButtonClick().popOutButtonClick().toInputSendKeys(email.getToInputText()).subjectInputSendKeys(email.getSubjectInputText()).
                bodyInputSendKeys(email.getBodyInputText()).closeButtonClick();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        int finalDraftsNumber = gmailPage.getDraftsNumber();
        System.out.println("finalDraftsNumber: " + finalDraftsNumber);
        Assert.assertTrue(finalDraftsNumber == initialDraftsNumber + 1, "Email was not added to 'Drafts' folder");
    }

    @AfterMethod(description = "Close browser, kill webdriver")
    public void kill() {
        WebDriverSingleton.kill();
    }
}
