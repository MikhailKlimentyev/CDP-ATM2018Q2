/**
 * EmailDecorator.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 8/12/2018
 */

package com.epam.cdp.atm2018q2.m09.bo;

public abstract class EmailDecorator {
    protected Email email;

    public EmailDecorator(Email email) {
        this.email = email;
    }
}

