/**
 * MessagePage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/21/2018
 */

package com.epam.cdp.atm2018q2.m09.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

public class EmailPage extends GmailPage {
    private static final By POP_OUT_BUTTON_LOCATOR = By.xpath("//table[@class='cf Ht']/tbody/tr/td[@class='Hm']/img[@class='Hq aUG']");
    private static final By TO_INPUT_LOCATOR = By.xpath("//textarea[@name='to']");
    private static final By SUBJECT_INPUT_LOCATOR = By.xpath("//div[@class='aoD az6']/input[@name='subjectbox']");
    private static final By BODY_INPUT_LOCATOR = By.xpath("//div[@class='Am Al editable LW-avf'][@role='textbox']");
    private static final By CLOSE_BUTTON_LOCATOR = By.xpath("//img[@class='Ha'][@alt='Close']");
    private static final By ATTACHMENT_LABEL_LOCATOR = By.xpath("//div[@class='a1 aaA aMZ']");
    private static final By ADD_CC_LOCATOR = By.xpath("//span[@class='aB gQ pE']");
    private static final By CC_INPUT_LOCATOR = By.xpath("//textarea[@name='cc']");


    public EmailPage() {
        super();
    }

    public EmailPage popOutButtonClick() {
        waitForElementVisible(POP_OUT_BUTTON_LOCATOR);
        driver.findElement(POP_OUT_BUTTON_LOCATOR).click();
        return this;
    }

    public EmailPage toInputSendKeys(String toInputText) {
        waitForElementVisible(TO_INPUT_LOCATOR);
        driver.findElement(TO_INPUT_LOCATOR).sendKeys(toInputText, Keys.RETURN);
        return this;
    }

    public EmailPage subjectInputSendKeys(String subjectInputText) {
        waitForElementVisible(SUBJECT_INPUT_LOCATOR);
        driver.findElement(SUBJECT_INPUT_LOCATOR).sendKeys(subjectInputText);
        return this;
    }

    public EmailPage bodyInputSendKeys(String bodyInputText) {
        waitForElementVisible(BODY_INPUT_LOCATOR);
        driver.findElement(BODY_INPUT_LOCATOR).sendKeys(bodyInputText);
        return this;
    }

    public EmailPage attachFile(String filePath) {
        driver.findElement(ATTACHMENT_LABEL_LOCATOR).click();
        //upload file using RobotClass
        //attach path where file is located.
        StringSelection ss = new StringSelection(filePath);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
        Robot robot = null;
        try {
            robot = new Robot();
        } catch (AWTException e) {
            e.printStackTrace();
        }
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.keyRelease(KeyEvent.VK_V);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Attachment is added.");
        return this;
    }

    public GmailPage closeButtonClick() {
        waitForElementVisible(CLOSE_BUTTON_LOCATOR);
        driver.findElement(CLOSE_BUTTON_LOCATOR).click();
        return new GmailPage();
    }

    public EmailPage ccIconClick() {
        waitForElementVisible(ADD_CC_LOCATOR);
        driver.findElement(ADD_CC_LOCATOR).click();
        return this;
    }

    public EmailPage ccInputSendKeys(String ccInputText) {
        waitForElementVisible(CC_INPUT_LOCATOR);
        driver.findElement(CC_INPUT_LOCATOR).sendKeys(ccInputText);
        return this;
    }
}
