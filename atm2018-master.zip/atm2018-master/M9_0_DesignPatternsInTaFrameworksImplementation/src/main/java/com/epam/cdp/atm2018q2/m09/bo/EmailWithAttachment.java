/**
 * EmailWithAttachment.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 8/12/2018
 */

package com.epam.cdp.atm2018q2.m09.bo;

import java.io.File;

public class EmailWithAttachment extends EmailDecorator {
    private File file;

    public EmailWithAttachment(Email email, File file) {
        super(email);
        this.file = file;
    }

    public File getFile() {
        return file;
    }
}
