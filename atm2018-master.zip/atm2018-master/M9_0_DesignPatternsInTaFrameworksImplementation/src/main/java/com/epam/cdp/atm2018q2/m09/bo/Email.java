/**
 * Email.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 8/12/2018
 */

package com.epam.cdp.atm2018q2.m09.bo;

public class Email {
    private String toInputText;
    private String subjectInputText;
    private String bodyInputText;

    public Email(String toInputText, String subjectInputText, String bodyInputText) {
        this.toInputText = toInputText;
        this.subjectInputText = subjectInputText;
        this.bodyInputText = bodyInputText;
    }

    public String getToInputText() {
        return toInputText;
    }

    public void setToInputText(String toInputText) {
        this.toInputText = toInputText;
    }

    public void setSubjectInputText(String subjectInputText) {
        this.subjectInputText = subjectInputText;
    }

    public void setBodyInputText(String bodyInputText) {
        this.bodyInputText = bodyInputText;
    }

    public String getSubjectInputText() {

        return subjectInputText;
    }

    public String getBodyInputText() {
        return bodyInputText;
    }
}
