/**
 * User.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 8/5/2018
 */

package com.epam.cdp.atm2018q2.m09.bo;

public enum Accounts {
    ACCOUNT_WITH_VALID_CREDENTIALS("foratm2018q@gmail.com", "atm2018q");

    private final String login;
    private final String password;

    Accounts(String login, String password) {
        this.login = login;
        this.password = password;
    }

    public String getLogin() {
        return login;
    }

    public String getPassword() {
        return password;
    }
}
