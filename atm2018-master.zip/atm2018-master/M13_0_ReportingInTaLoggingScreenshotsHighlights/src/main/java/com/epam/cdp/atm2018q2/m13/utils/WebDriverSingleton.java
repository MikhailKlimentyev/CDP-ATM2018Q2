/**
 * WebDriverSingleton.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/14/2018
 */

package com.epam.cdp.atm2018q2.m13.utils;

import com.epam.cdp.atm2018q2.m13.reporting.MyLogger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class WebDriverSingleton {
    private static WebDriver instance;

    private WebDriverSingleton() {
    }

    public static WebDriver getWebDriverInstance() {
        if (instance != null) {
            return instance;
        }
        return instance = init();
    }

    private static WebDriver init() {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe"); // do not forget to add chromedriver.exe file to src/main/resources/
        WebDriver driver = new ChromeDriver();
        MyLogger.debug("WebDriver instance is created.");
        driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        return driver;
    }

    public static void kill() {
        if (instance != null) {
            try {
                instance.quit();
                MyLogger.debug("WebDriver instance is guit.");
            } catch (Exception e) {
                MyLogger.error("Cannot kill WebDriver instance. " + e.getMessage());
            } finally {
                instance = null;
                MyLogger.debug("WebDriver instance is null.");
            }
        }
    }
}