/**
 * GmailPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/21/2018
 */

package com.epam.cdp.atm2018q2.m13.pages;

import com.epam.cdp.atm2018q2.m13.reporting.MyLogger;
import com.epam.cdp.atm2018q2.m13.utils.Screenshoter;
import org.openqa.selenium.By;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GmailPage extends AbstractPage {
    private static final By ACCOUNT_ICON_LOCATOR = By.xpath("//a[@class='gb_b gb_eb gb_R'][@role='button']");
    private static final By COMPOSE_BUTTON_LOCATOR = By.xpath("//div[@class='T-I J-J5-Ji T-I-KE L3'][@role='button']");
    private static final By DRAFTS_ICON_LOCATOR = By.xpath("//a[@class='J-Ke n0'][contains(text(), 'Drafts')]");
    private static final By SENT_MAIL_ICON_LOCATOR = By.xpath("//a[@class='J-Ke n0'][contains(text(), 'Sent Mail')]");

    public GmailPage() {
        super();
    }

    public AccountPage accountIconClick() {
        try {
            MyLogger.info("Click on ACCOUNT_ICON WebElement on GmailPage.");
            waitForElementVisible(ACCOUNT_ICON_LOCATOR);
            highlightElement(ACCOUNT_ICON_LOCATOR);
            driver.findElement(ACCOUNT_ICON_LOCATOR).click();
            MyLogger.info("Clicked on ACCOUNT_ICON WebElement on GmailPage.");
        } catch (Exception e) {
            MyLogger.error("Failed to click on ACCOUNT_ICON WebElement. " + e.getMessage());
            MyLogger.attach(Screenshoter.takeScreenshot(), " Screenshot is attached");
        }
        return new AccountPage();
    }

    public EmailPage composeButtonClick() {
        waitForElementVisible(COMPOSE_BUTTON_LOCATOR);
        driver.findElement(COMPOSE_BUTTON_LOCATOR).click();
        return new EmailPage();
    }

    public DraftsPage draftsIconClick() {
        waitForElementVisible(DRAFTS_ICON_LOCATOR);
        driver.findElement(DRAFTS_ICON_LOCATOR).click();
        return new DraftsPage();
    }

    public int getDraftsNumber() {
        waitForElementVisible(DRAFTS_ICON_LOCATOR);
        String draftsIconText = driver.findElement(DRAFTS_ICON_LOCATOR).getText();
        Pattern pattern = Pattern.compile("\\d+");
        Matcher matcher = pattern.matcher(draftsIconText);
        int draftsNumber = 0;
        while (matcher.find()) {
            String draftsIconNumber = draftsIconText.substring(matcher.start(), matcher.end());
            draftsNumber = Integer.parseInt(draftsIconNumber);
        }
        return draftsNumber;
    }

    public SentEmailPage sentMailIconClick() {
        waitForElementVisible(SENT_MAIL_ICON_LOCATOR);
        driver.findElement(SENT_MAIL_ICON_LOCATOR).click();
        return new SentEmailPage();
    }

}
