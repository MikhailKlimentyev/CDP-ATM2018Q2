/**
 * AccountPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/21/2018
 */

package com.epam.cdp.atm2018q2.m13.pages;

import com.epam.cdp.atm2018q2.m13.reporting.MyLogger;
import com.epam.cdp.atm2018q2.m13.utils.Screenshoter;
import org.openqa.selenium.By;

public class AccountPage extends GmailPage {
    private static final By EMAIL_ON_ACCOUNT_ICON_LOCATOR = By.xpath("//div [@class='gb_zb']/div[@class='gb_Eb']");
    private static final By SIGN_OUT_BUTTON_LOCATOR = By.xpath("//a[@id='gb_71']");

    public AccountPage() {
        super();
    }

    public PasswordPage signOutButtonClick() {
        try {
            MyLogger.info("Click on SIGN_OUT_BUTTON WebElement on AccountPage.");
            waitForElementVisible(SIGN_OUT_BUTTON_LOCATOR);
            highlightElement(SIGN_OUT_BUTTON_LOCATOR);
            driver.findElement(SIGN_OUT_BUTTON_LOCATOR).click();
            MyLogger.info("Click on SIGN_OUT_BUTTON WebElement on AccountPage.");
        } catch (Exception e) {
            Screenshoter.takeScreenshot();
            MyLogger.error("Failed to click on SIGN_OUT_BUTTON WebElement on AccountPage. " + e.getMessage());
        }
        return new PasswordPage();
    }

    public static By getEmailOnAccountIconLocator() {
        return EMAIL_ON_ACCOUNT_ICON_LOCATOR;
    }

    public static By getSignOutButtonLocator() {
        return SIGN_OUT_BUTTON_LOCATOR;
    }
}
