/**
 * Screenshoter.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/29/2018
 */

package com.epam.cdp.atm2018q2.m13.utils;

import com.epam.cdp.atm2018q2.m13.reporting.MyLogger;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;

public class Screenshoter {
    private static final String SCREENSHOTS_NAME_TPL = "screenshots/scr";

    public static String takeScreenshot() {
        WebDriver driver = WebDriverSingleton.getWebDriverInstance();
        File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        String screenshotName = SCREENSHOTS_NAME_TPL;
        try {
            screenshotName = SCREENSHOTS_NAME_TPL + System.nanoTime() + ".png";
            File copy = new File(screenshotName);
            FileUtils.copyFile(screenshot, copy);
            MyLogger.warn("Saved screenshot: " + screenshotName);
        } catch (IOException e) {
            MyLogger.error("Failed to make screenshot");
        }
        return screenshotName;
    }
}
