/**
 * PasswordPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/21/2018
 */

package com.epam.cdp.atm2018q2.m13.pages;

import com.epam.cdp.atm2018q2.m13.reporting.MyLogger;
import com.epam.cdp.atm2018q2.m13.utils.Screenshoter;
import org.openqa.selenium.By;

public class PasswordPage extends AbstractPage {
    private static final By PASSWORD_INPUT_LOCATOR = By.xpath("//input[@type='password'][@name='password']");
    private static final By NEXT_BUTTON_LOCATOR = By.xpath("//div[@id='passwordNext']");
    private static final By HEADING_TEXT_LOCATOR = By.xpath("//h1[@id='headingText']");

    public PasswordPage() {
        super();
    }

    public static By getHeadingTextLocator() {
        return HEADING_TEXT_LOCATOR;
    }

    public PasswordPage fillPasswordInput(String password) {
        try {
            MyLogger.info("Send keys '" +  password + "' to PASSWORD_INPUT WebElement on PasswordPage.");
            waitForElementVisible(PASSWORD_INPUT_LOCATOR);
            highlightElement(PASSWORD_INPUT_LOCATOR);
            driver.findElement(PASSWORD_INPUT_LOCATOR).sendKeys(password);
            MyLogger.info("Sent keys '" +  password + "' to PASSWORD_INPUT WebElement on PasswordPage.");
        } catch (Exception e) {
            MyLogger.error("Failed to send keys '" + password  + "' to PASSWORD_INPUT WebElement on PasswordPage. " + e.getMessage());
            MyLogger.attach(Screenshoter.takeScreenshot(), " Screenshot is attached");
        }
        return this;
    }

    public GmailPage nextButtonClick() {
        try {
            MyLogger.info("Click on NEXT_BUTTON WebElement on PasswordPage.");
            waitForElementVisible(NEXT_BUTTON_LOCATOR);
            highlightElement(NEXT_BUTTON_LOCATOR);
            driver.findElement(NEXT_BUTTON_LOCATOR).click();
            MyLogger.info("Clicked on NEXT_BUTTON WebElement on PasswordPage.");
        } catch (Exception e) {
            MyLogger.error("Failed to click on NEXT_BUTTON WebElement PasswordPage. " + e.getMessage());
            MyLogger.attach(Screenshoter.takeScreenshot(), " Screenshot is attached");
        }
        return new GmailPage();
    }


}
