/**
 * AbstractPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/27/2018
 */

package com.epam.cdp.atm2018q2.m13.pages;

import com.epam.cdp.atm2018q2.m13.reporting.MyLogger;
import com.epam.cdp.atm2018q2.m13.utils.Screenshoter;
import com.epam.cdp.atm2018q2.m13.utils.WebDriverSingleton;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public abstract class AbstractPage {
    protected WebDriver driver;
    private static final int DEFAULT_TIMEOUT = 10;

    protected AbstractPage() {
        this.driver = WebDriverSingleton.getWebDriverInstance();
    }

    public boolean isElementVisible(By locator) {
        waitForElementVisible(locator);
        boolean success = driver.findElements(locator).size() > 0;
        if (success) {
            MyLogger.info("Element with " + locator + "is visible.");
        } else {
            Screenshoter.takeScreenshot();
            MyLogger.error("Element with " + locator + "is not visible.");
        }
        return success;
    }

    public boolean isElementPresent(By locator) {
        waitForElementPresent(locator);
        boolean success = driver.findElements(locator).size() > 0;
        if (success) {
            MyLogger.info("Element with " + locator + "presents.");
        } else {
            Screenshoter.takeScreenshot();
            MyLogger.error("Element with " + locator + "does not present.");
        }
        return success;
    }

    public void waitForElementVisible(By locator) {
        new WebDriverWait(driver, DEFAULT_TIMEOUT).until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    public void waitForElementPresent(By locator) {
        new WebDriverWait(driver, DEFAULT_TIMEOUT).until(ExpectedConditions.presenceOfElementLocated(locator));
    }

    public void waitForElementEnabled(By locator) {
        new WebDriverWait(driver, DEFAULT_TIMEOUT).until(ExpectedConditions.elementToBeClickable(locator));
    }

    public boolean isAlertPresent() {
        try {
            driver.switchTo().alert();
            return true;
        } catch (NoAlertPresentException Ex) {
            return false;
        }
    }

    public void highlightElement(By locator) {
        WebElement element = driver.findElement(locator);
        ((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px solid green'", element);
    }

    public void unHighlightElement(By locator) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].style.border='0px'", driver.findElement(locator));
    }
}
