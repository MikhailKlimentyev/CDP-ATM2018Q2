/**
 * LoginPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 2.0
 * @since 9/16/2018
 */

package com.epam.cdp.atm2018q2.m13.pages;

import com.epam.cdp.atm2018q2.m13.reporting.MyLogger;
import com.epam.cdp.atm2018q2.m13.utils.GlobalConstants;
import com.epam.cdp.atm2018q2.m13.utils.Screenshoter;
import org.openqa.selenium.By;

public class LoginPage extends AbstractPage {
    private static final By LOGIN_INPUT_LOCATOR = By.xpath("//input[@type='email'][@class='whsOnd zHQkBf'][@autocomplete='username']");
    private static final By NEXT_BUTTON_LOCATOR = By.xpath("//div[@id='identifierNext'][@role='button']");

    public LoginPage() {
        super();
    }

    public LoginPage open() {
        try {
            MyLogger.info("Open " + GlobalConstants.getURL() + ". ");
            driver.get(GlobalConstants.getURL());
            MyLogger.info("Opened " + GlobalConstants.getURL() + ". ");
        } catch (Exception e) {
            Screenshoter.takeScreenshot();
            MyLogger.error("Failed to open " + GlobalConstants.getURL() + ". " + e.getMessage());
            MyLogger.attach(Screenshoter.takeScreenshot(), " Screenshot is attached");
        }
        return this;
    }

    public LoginPage fillLoginInput(String login) {
        try {
            MyLogger.info("Send keys '" + login + "' to LOGIN_INPUT WebElement on LoginPage.");
            waitForElementVisible(LOGIN_INPUT_LOCATOR);
            highlightElement(LOGIN_INPUT_LOCATOR);
            driver.findElement(LOGIN_INPUT_LOCATOR).sendKeys(login);
            MyLogger.info("Sent keys '" + login + "' to LOGIN_INPUT WebElement on LoginPage.");
        } catch (Exception e) {
            MyLogger.error("Failed to send keys '" + login + "' to LOGIN_INPUT WebElement on LoginPage. " + e.getMessage());
            MyLogger.attach(Screenshoter.takeScreenshot(), "1212");
        }
        return this;
    }

    public PasswordPage nextButtonClick() {
        try {
            MyLogger.info("Click on NEXT_BUTTON WebElement on LoginPage.");
            waitForElementVisible(NEXT_BUTTON_LOCATOR);
            highlightElement(NEXT_BUTTON_LOCATOR);
            driver.findElement(NEXT_BUTTON_LOCATOR).click();
            MyLogger.info("Clicked on NEXT_BUTTON WebElement on LoginPage.");
        } catch (Exception e) {
            MyLogger.error("Failed to click on NEXT_BUTTON WebElement on LoginPage. " + e.getMessage());
            MyLogger.attach(Screenshoter.takeScreenshot(), " Screenshot is attached");
        }
        return new PasswordPage();
    }
}
