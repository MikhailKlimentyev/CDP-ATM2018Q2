/**
 * MyLogger.
 *
 * @author Mikhail Klimentsyeu
 * @version 2.0
 * @since 9/22/2018
 */

package com.epam.cdp.atm2018q2.m13.reporting;

//import org.apache.log4j.Logger;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class MyLogger {
    // log4j
    // private static final Logger LOGGER = Logger.getLogger(MyLogger.class);

    // log4j2
    private static final Logger lOGGER = LogManager.getLogger(MyLogger.class);

    public static void info(String message) {
        lOGGER.info(message);
    }

    public static void error(String message) {
        lOGGER.error(message);
    }

    public static void debug(String message) {
        lOGGER.debug(message);
    }

    public static void warn(String message) {
        lOGGER.warn(message);
    }

    public static void attach(String filePath, String message) {
        lOGGER.info("RP_MESSAGE#FILE#{}#{}", filePath, message);
    }
}
