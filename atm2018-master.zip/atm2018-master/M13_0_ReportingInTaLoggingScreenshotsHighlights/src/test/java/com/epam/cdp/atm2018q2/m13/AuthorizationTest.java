/**
 * AuthorizationTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/28/2018
 */

package com.epam.cdp.atm2018q2.m13;

import com.epam.cdp.atm2018q2.m13.pages.AccountPage;
import com.epam.cdp.atm2018q2.m13.pages.LoginPage;
import com.epam.cdp.atm2018q2.m13.reporting.MyLogger;
import com.epam.cdp.atm2018q2.m13.utils.GlobalConstants;
import com.epam.cdp.atm2018q2.m13.utils.WebDriverSingleton;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

public class AuthorizationTest {

    @Test(description = "Email label presents on account icon after authorization")
    public void emailLabelPresentsOnAccountIconTest() {
        MyLogger.debug("emailLabelPresentsOnAccountIconTest() is started.");
        AccountPage accountPage = new LoginPage().open().fillLoginInput(GlobalConstants.getLOGIN()).nextButtonClick().fillPasswordInput(GlobalConstants.getPASSWORD()).nextButtonClick().accountIconClick();
        Assert.assertTrue(accountPage.isElementVisible(accountPage.getEmailOnAccountIconLocator()), "Email label was not found on the account icon.");
        accountPage.signOutButtonClick();
        MyLogger.debug("emailLabelPresentsOnAccountIconTest() is finished.");
    }

    @Test(description = "'Sign out' button presents on account icon after authorization")
    public void signOutButtonPresentsOnAccountIconTest() {
        MyLogger.debug("signOutButtonPresentsOnAccountIconTest() is started.");
        AccountPage accountPage = new LoginPage().open().fillLoginInput(GlobalConstants.getLOGIN()).nextButtonClick().fillPasswordInput(GlobalConstants.getPASSWORD()).nextButtonClick().accountIconClick();
        Assert.assertTrue(accountPage.isElementVisible(accountPage.getSignOutButtonLocator()), "'Sign out' button was not found on the account icon.");
        accountPage.signOutButtonClick();
        MyLogger.debug("signOutButtonPresentsOnAccountIconTest() is finished.");
    }

    @Test(description = "This test is designed to demonstrate error lever of logger")
    public void failedAuthintificationTest() {
        MyLogger.debug("failedAuthintificationTest() is started.");
        AccountPage accountPage = new LoginPage().open().fillLoginInput(GlobalConstants.getLOGIN()).nextButtonClick().fillPasswordInput(GlobalConstants.getIncorrectPassword()).nextButtonClick().accountIconClick();
        Assert.assertTrue(accountPage.isElementVisible(accountPage.getSignOutButtonLocator()), "'Sign out' button was not found on the account icon.");
        accountPage.signOutButtonClick();
        MyLogger.debug("failedAuthintificationTest() is finished.");
    }

    @AfterMethod(description = "Close browser, kill webdriver")
    public void kill() {
        MyLogger.debug("kill() is started.");
        WebDriverSingleton.kill();
        MyLogger.debug("kill() is finished.");
    }
}
