/**
 * ComposeEmailTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/28/2018
 */

package com.epam.cdp.atm2018q2.m08;

import com.epam.cdp.atm2018q2.m08.pages.GmailPage;
import com.epam.cdp.atm2018q2.m08.pages.LoginPage;
import com.epam.cdp.atm2018q2.m08.utils.WebDriverSingleton;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import static com.epam.cdp.atm2018q2.m08.bo.Accounts.ACCOUNT_WITH_VALID_CREDENTIALS;
import static com.epam.cdp.atm2018q2.m08.bo.Emails.FIRST_EMAIL;

public class ComposeEmailTest {

    @Test(description = "Compose Email, close Email without sending, verify that composed email presents in drafts folder")
    public void verifyThatComposedEmailSavedInDraftsFolderTest() {
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(ACCOUNT_WITH_VALID_CREDENTIALS.getLogin()).nextButtonClick().fillPasswordInput(ACCOUNT_WITH_VALID_CREDENTIALS.getPassword()).nextButtonClick();
        int initialDraftsNumber = gmailPage.getDraftsNumber();
        System.out.println("composeEmailTest\ninitialDraftsNumber: " + initialDraftsNumber);
        gmailPage.composeButtonClick().popOutButtonClick().toInputSendKeys(FIRST_EMAIL.getToInputText()).subjectInputSendKeys(FIRST_EMAIL.getSubjectInputText()).
                bodyInputSendKeys(FIRST_EMAIL.getBodyInputText()).closeButtonClick();
        int finalDraftsNumber = gmailPage.getDraftsNumber();
        System.out.println("finalDraftsNumber: " + finalDraftsNumber);
        Assert.assertTrue(finalDraftsNumber == initialDraftsNumber + 1, "Email was not added to 'Drafts' folder");
    }

    @AfterMethod(description = "Close browser, kill webdriver")
    public void kill() {
        WebDriverSingleton.kill();
    }
}
