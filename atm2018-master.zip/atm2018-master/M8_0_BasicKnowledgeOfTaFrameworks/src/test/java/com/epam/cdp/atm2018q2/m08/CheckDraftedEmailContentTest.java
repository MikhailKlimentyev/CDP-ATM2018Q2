/**
 * CheckDraftedEmailContentTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/28/2018
 */

package com.epam.cdp.atm2018q2.m08;

import com.epam.cdp.atm2018q2.m08.pages.DraftEmailPage;
import com.epam.cdp.atm2018q2.m08.pages.GmailPage;
import com.epam.cdp.atm2018q2.m08.pages.LoginPage;
import com.epam.cdp.atm2018q2.m08.utils.WebDriverSingleton;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import static com.epam.cdp.atm2018q2.m08.bo.Accounts.ACCOUNT_WITH_VALID_CREDENTIALS;
import static com.epam.cdp.atm2018q2.m08.bo.Emails.FIRST_EMAIL;

public class CheckDraftedEmailContentTest {

    @Test(description = "Compare 'To' field content of composed email and drafted email")
    public void checkToInputContentOfDraftedEmailTest() {
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(ACCOUNT_WITH_VALID_CREDENTIALS.getLogin()).nextButtonClick().
                fillPasswordInput(ACCOUNT_WITH_VALID_CREDENTIALS.getPassword()).nextButtonClick().composeButtonClick().popOutButtonClick().
                toInputSendKeys(FIRST_EMAIL.getToInputText()).subjectInputSendKeys(FIRST_EMAIL.getSubjectInputText()).
                bodyInputSendKeys(FIRST_EMAIL.getBodyInputText()).closeButtonClick();
        DraftEmailPage draftEmailPage = gmailPage.draftsIconClick().draftEmailCheckboxClick().draftLabelClick();
        Assert.assertEquals(draftEmailPage.getToInputText(), FIRST_EMAIL.getToInputText(), "Text in 'To' field of drafted email is not valid");
    }

    @Test(description = "Compare 'Subject' field content of composed email and drafted email")
    public void checkSubjectInputContentOfDraftedEmailTest() {
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(ACCOUNT_WITH_VALID_CREDENTIALS.getLogin()).nextButtonClick().
                fillPasswordInput(ACCOUNT_WITH_VALID_CREDENTIALS.getPassword()).nextButtonClick().composeButtonClick().popOutButtonClick().
                toInputSendKeys(FIRST_EMAIL.getToInputText()).subjectInputSendKeys(FIRST_EMAIL.getSubjectInputText()).
                bodyInputSendKeys(FIRST_EMAIL.getBodyInputText()).closeButtonClick();
        DraftEmailPage draftEmailPage = gmailPage.draftsIconClick().draftEmailCheckboxClick().draftLabelClick();
        Assert.assertEquals(draftEmailPage.getSubjectInputText(), FIRST_EMAIL.getSubjectInputText(), "Text in 'Subject' field of drafted email is not valid");
    }

    @Test(description = "Compare 'Body' field content of composed email and drafted email")
    public void checkBodyInputContentOfDraftedEmailTest() {
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(ACCOUNT_WITH_VALID_CREDENTIALS.getLogin()).nextButtonClick().
                fillPasswordInput(ACCOUNT_WITH_VALID_CREDENTIALS.getPassword()).nextButtonClick().composeButtonClick().popOutButtonClick().
                toInputSendKeys(FIRST_EMAIL.getToInputText()).subjectInputSendKeys(FIRST_EMAIL.getSubjectInputText()).
                bodyInputSendKeys(FIRST_EMAIL.getBodyInputText()).closeButtonClick();
        DraftEmailPage draftEmailPage = gmailPage.draftsIconClick().draftEmailCheckboxClick().draftLabelClick();
        Assert.assertEquals(draftEmailPage.getBodyInputText(), FIRST_EMAIL.getBodyInputText(), "Text in 'Body' field of drafted email is not valid");
    }

    @Test(description = "Compare Header content of composed email and drafted email")
    public void checkHeaderContentOfDraftedEmailTest() {
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(ACCOUNT_WITH_VALID_CREDENTIALS.getLogin()).nextButtonClick().
                fillPasswordInput(ACCOUNT_WITH_VALID_CREDENTIALS.getPassword()).nextButtonClick().composeButtonClick().popOutButtonClick().
                toInputSendKeys(FIRST_EMAIL.getToInputText()).subjectInputSendKeys(FIRST_EMAIL.getSubjectInputText()).
                bodyInputSendKeys(FIRST_EMAIL.getBodyInputText()).closeButtonClick();
        DraftEmailPage draftEmailPage = gmailPage.draftsIconClick().draftEmailCheckboxClick().draftLabelClick();
        Assert.assertEquals(draftEmailPage.getHeaderText(), FIRST_EMAIL.getSubjectInputText(), "Text of Header of drafted email is not valid");
    }

    @AfterMethod(description = "Close browser, kill webdriver")
    public void kill() {
        WebDriverSingleton.kill();
    }
}
