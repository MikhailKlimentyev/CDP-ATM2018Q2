/**
 * PasswordPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/21/2018
 */

package com.epam.cdp.atm2018q2.m08.pages;

import org.openqa.selenium.By;

public class PasswordPage extends GmailPage {
    private static final By PASSWORD_INPUT_LOCATOR = By.xpath("//input[@type='password'][@name='password']");
    private static final By NEXT_BUTTON_LOCATOR = By.xpath("//div[@id='passwordNext']");
    private static final By HEADING_TEXT_LOCATOR = By.xpath("//h1[@id='headingText']");

    public PasswordPage() {
        super();
    }

    public static By getHeadingTextLocator() {
        return HEADING_TEXT_LOCATOR;
    }

    public PasswordPage fillPasswordInput(String password) {
        waitForElementVisible(PASSWORD_INPUT_LOCATOR);
        driver.findElement(PASSWORD_INPUT_LOCATOR).sendKeys(password);
        return this;
    }

    public GmailPage nextButtonClick() {
        waitForElementVisible(NEXT_BUTTON_LOCATOR);
        driver.findElement(NEXT_BUTTON_LOCATOR).click();
        return new GmailPage();
    }


}
