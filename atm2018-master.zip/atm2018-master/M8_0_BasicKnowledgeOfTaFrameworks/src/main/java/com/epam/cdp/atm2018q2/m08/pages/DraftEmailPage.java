/**
 * DraftEmailPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/22/2018
 */

package com.epam.cdp.atm2018q2.m08.pages;

import org.openqa.selenium.By;

public class DraftEmailPage extends GmailPage {
    private static final By TO_INPUT_LOCATOR = By.xpath("//div[@class='oL aDm az9']/span");
    private static final By SUBJECT_INPUT_LOCATOR = By.xpath("//form[@class='bAs']/input[@name='subject']");
    private static final By BODY_INPUT_LOCATOR = By.xpath("//div[@class='Am Al editable LW-avf']");
    private static final By HEADER_LOCATOR = By.xpath("//div[@class='Hp']/h2[@class='a3E']/div[@class='aYF']");
    private static final By SEND_BUTTON_LOCATOR = By.xpath("//div[@class='J-J5-Ji btA']/div[@role='button'][text()='Send']");

    public DraftEmailPage() {
        super();
    }

    public String getToInputText() {
        return driver.findElement(TO_INPUT_LOCATOR).getText();
    }

    public String getSubjectInputText() {
        return driver.findElement(SUBJECT_INPUT_LOCATOR).getAttribute("value");
    }

    public String getBodyInputText() {
        return driver.findElement(BODY_INPUT_LOCATOR).getText();
    }

    public String getHeaderText() {
        return driver.findElement(HEADER_LOCATOR).getText();
    }

    public GmailPage sendButtonClick() {
        waitForElementVisible(SEND_BUTTON_LOCATOR);
        driver.findElement(SEND_BUTTON_LOCATOR).click();
        return new GmailPage();
    }
}