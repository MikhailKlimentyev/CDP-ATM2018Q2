/**
 * MessagePage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/21/2018
 */

package com.epam.cdp.atm2018q2.m08.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

public class EmailPage extends GmailPage {
    private static final By POP_OUT_BUTTON_LOCATOR = By.xpath("//table[@class='cf Ht']/tbody/tr/td[@class='Hm']/img[@class='Hq aUG']");
    private static final By TO_INPUT_LOCATOR = By.xpath("//div[@class='wO nr l1']/textarea[@class='vO'][@role='combobox']");
    private static final By SUBJECT_INPUT_LOCATOR = By.xpath("//div[@class='aoD az6']/input[@name='subjectbox'][@class='aoT']");
    private static final By BODY_INPUT_LOCATOR = By.xpath("//div[@class='Am Al editable LW-avf'][@role='textbox']");
    private static final By CLOSE_BUTTON_LOCATOR = By.xpath("//img[@class='Ha'][@alt='Close']");

    public EmailPage() {
        super();
    }

    public EmailPage popOutButtonClick() {
        waitForElementVisible(POP_OUT_BUTTON_LOCATOR);
        driver.findElement(POP_OUT_BUTTON_LOCATOR).click();
        return this;
    }

    public EmailPage toInputSendKeys(String toInputText) {
        waitForElementVisible(TO_INPUT_LOCATOR);
        driver.findElement(TO_INPUT_LOCATOR).sendKeys(toInputText, Keys.RETURN);
        return this;
    }

    public EmailPage subjectInputSendKeys(String subjectInputText) {
        waitForElementVisible(SUBJECT_INPUT_LOCATOR);
        driver.findElement(SUBJECT_INPUT_LOCATOR).sendKeys(subjectInputText);
        return this;
    }

    public EmailPage bodyInputSendKeys(String bodyInputText) {
        waitForElementVisible(BODY_INPUT_LOCATOR);
        driver.findElement(BODY_INPUT_LOCATOR).sendKeys(bodyInputText);
        return this;
    }

    public GmailPage closeButtonClick() {
        waitForElementVisible(CLOSE_BUTTON_LOCATOR);
        driver.findElement(CLOSE_BUTTON_LOCATOR).click();
        return new GmailPage();
    }
}
