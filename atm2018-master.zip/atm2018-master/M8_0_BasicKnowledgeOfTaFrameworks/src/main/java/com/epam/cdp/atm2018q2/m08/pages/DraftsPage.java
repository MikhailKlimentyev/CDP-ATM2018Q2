/**
 * DraftsPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/22/2018
 */

package com.epam.cdp.atm2018q2.m08.pages;

import com.epam.cdp.atm2018q2.m08.utils.Screenshoter;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.ArrayList;
import java.util.List;

public class DraftsPage extends GmailPage {
    private static final By DRAFT_LABEL_LOCATOR = By.xpath("//div[@class='yW']/font[text()='Draft']");
    private static final By DRAFT_EMAIL_CHECKBOX_LOCATOR = By.xpath("//div[@class='ae4 UI']/div[@class='Cp']/div/table[@class='F cf zt']/tbody/tr[@class='zA yO']/td[@class='oZ-x3 xY']/div/div");
    private static final By DRAFT_EMAIL_CHECKBOX_AREA_LOCATOR = By.xpath("//tr[@class='zA yO x7']/td[@class='oZ-x3 xY']");
    public static final By TRASH_FOLDER_LOCATOR = By.xpath("//div[@class='aio UKr6le']/span[@class='nU ']/a[@title='Trash']");
    public static final By MORE_DROPDOWN_LOCATOR = By.xpath("//span[@role='button']/span[@class='CJ']");

    public DraftsPage() {
        super();
    }

    public DraftEmailPage draftLabelClick() {
        waitForElementVisible(DRAFT_LABEL_LOCATOR);

        driver.findElement(DRAFT_LABEL_LOCATOR).click();
        return new DraftEmailPage();
    }

    public DraftsPage draftEmailCheckboxClick() {
        waitForElementVisible(DRAFT_EMAIL_CHECKBOX_LOCATOR);
        driver.findElement(DRAFT_EMAIL_CHECKBOX_LOCATOR).click();
        return this;

    }

    public DraftsPage draftEmailCheckboxContextMenuCall() {
        Actions contextClick = new Actions(driver).contextClick(driver.findElement(DRAFT_EMAIL_CHECKBOX_LOCATOR));
        contextClick.sendKeys(Keys.ARROW_UP).sendKeys(Keys.RETURN).build().perform();
        return this;
    }

    public DraftsPage multiClickCheckboxes() {
        Screenshoter.takeScreenshot();
        List<WebElement> checkboxes = new ArrayList();
        checkboxes = driver.findElements(DRAFT_EMAIL_CHECKBOX_LOCATOR);
        Actions actions = new Actions(driver);
        actions.keyDown(Keys.LEFT_CONTROL).click(checkboxes.get(0)).
                click(checkboxes.get(1)).click(checkboxes.get(2)).keyUp(Keys.LEFT_CONTROL).build().perform();
        Screenshoter.takeScreenshot();
        return this;
    }

    public DraftsPage dragAndDropDraftedEmailsToTrashFolder() {
        WebElement draggable = driver.findElement(DRAFT_EMAIL_CHECKBOX_AREA_LOCATOR);
        WebElement droppable = driver.findElement(TRASH_FOLDER_LOCATOR);
        highlightElement(DRAFT_EMAIL_CHECKBOX_AREA_LOCATOR);
        highlightElement(TRASH_FOLDER_LOCATOR);
        Screenshoter.takeScreenshot();
        new Actions(driver).dragAndDrop(draggable, droppable).build().perform();
        try {
            Thread.sleep(300);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        unHighlightElement(DRAFT_EMAIL_CHECKBOX_AREA_LOCATOR);
        unHighlightElement(TRASH_FOLDER_LOCATOR);
        Screenshoter.takeScreenshot();
        return this;
    }

    public DraftsPage openMoreDropDown() {
        highlightElement(MORE_DROPDOWN_LOCATOR);
        Screenshoter.takeScreenshot();
        driver.findElement(MORE_DROPDOWN_LOCATOR).click();
        unHighlightElement(MORE_DROPDOWN_LOCATOR);
        Screenshoter.takeScreenshot();
        return this;
    }
}