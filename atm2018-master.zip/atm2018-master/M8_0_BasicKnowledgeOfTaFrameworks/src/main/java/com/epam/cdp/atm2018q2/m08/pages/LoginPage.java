/**
 * AuthorizationPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/21/2018
 */

package com.epam.cdp.atm2018q2.m08.pages;

import com.epam.cdp.atm2018q2.m08.utils.GlobalConstants;
import org.openqa.selenium.By;

public class LoginPage extends GmailPage {
    private static final By LOGIN_INPUT_LOCATOR = By.xpath("//input[@type='email'][@class='whsOnd zHQkBf'][@autocomplete='username']");
    private static final By NEXT_BUTTON_LOCATOR = By.xpath("//div[@id='identifierNext'][@role='button']");

    public LoginPage() {
        super();
    }

    public LoginPage open() {
        driver.get(GlobalConstants.getURL());
        return this;
    }

    public LoginPage fillLoginInput(String login) {
        waitForElementVisible(LOGIN_INPUT_LOCATOR);
        driver.findElement(LOGIN_INPUT_LOCATOR).sendKeys(login);
        return this;
    }

    public PasswordPage nextButtonClick() {
        waitForElementVisible(NEXT_BUTTON_LOCATOR);
        driver.findElement(NEXT_BUTTON_LOCATOR).click();
        return new PasswordPage();
    }
}
