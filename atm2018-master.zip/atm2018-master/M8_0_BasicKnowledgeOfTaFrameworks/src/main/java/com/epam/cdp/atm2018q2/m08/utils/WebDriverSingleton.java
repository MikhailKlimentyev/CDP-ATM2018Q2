/**
 * WebDriverSingleton.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/14/2018
 */

package com.epam.cdp.atm2018q2.m08.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import java.util.concurrent.TimeUnit;

public class WebDriverSingleton {
    private static WebDriver driver;
    private static Driver driverType;

    private WebDriverSingleton() {
        //block constructor
    }

    public enum Driver {
        FIREFOX, CHROME, IE
    }

    public static void setDriver(Driver driverType){
        WebDriverSingleton.driverType = driverType;
    }

    public static WebDriver getWebDriverInstance() {
        if(driver == null) {
            switch (driverType) {
                case CHROME:
                    System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
                    driver = new ChromeDriver();
                    break;
                case FIREFOX:
                    System.setProperty("webdriver.gecko.driver", "src/main/resources/geckodriver.exe");
                    driver = new FirefoxDriver();
                    break;
                case IE:
                    System.setProperty("webdriver.ie.driver", "src/main/resources/IEDriverServer.exe");
                    driver = new InternetExplorerDriver();
                    break;
                default:
                    System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
                    driver = new ChromeDriver();
                    break;
            }
            driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            driver.manage().window().maximize();
            return driver;
        } else {
            return driver;
        }
    }

    public static void kill() {
        if (driver != null) {
            try {
                driver.quit();
            } catch (Exception e) {
                System.out.println("Cannot kill browser");
            } finally {
                driver = null;
            }
        }
    }
}
