/**
 * GlobalConstants.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/27/2018
 */

package com.epam.cdp.atm2018q2.m08.utils;

public class GlobalConstants {
    private static final String URL = "https://mail.google.com";

    public static String getURL() {
        return URL;
    }

}
