/**
 * WebDriverSingleton.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/14/2018
 */

package com.epam.cdp.atm2018q2.m07.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

public class WebDriverSingleton {
    private static WebDriver instance;

    private WebDriverSingleton() {
    }

    public static WebDriver getWebDriverInstance() {
        if (instance != null) {
            return instance;
        }
        return instance = init();
    }

    private static WebDriver init() {
//        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe"); // do not forget to add chromedriver.exe file to src/main/resources/
//        WebDriver driver = new ChromeDriver();
        ThreadLocal<RemoteWebDriver> threadDriver = null;
//        WebDriver driver = null;

        threadDriver = new ThreadLocal<RemoteWebDriver>();
        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setBrowserName("chrome");
        try {
            threadDriver.set(new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), caps));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        threadDriver.get().manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
        threadDriver.get().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        threadDriver.get().manage().window().maximize();
        return threadDriver.get();
    }

    public static void kill() {
        if (instance != null) {
            try {
                instance.quit();
            } catch (Exception e) {
                System.out.println("Cannot kill browser");
            } finally {
                instance = null;
            }
        }
    }
}