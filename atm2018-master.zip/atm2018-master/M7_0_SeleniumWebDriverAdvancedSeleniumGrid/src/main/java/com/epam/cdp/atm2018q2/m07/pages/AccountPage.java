/**
 * AccountPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/21/2018
 */

package com.epam.cdp.atm2018q2.m07.pages;

import org.openqa.selenium.By;

public class AccountPage extends GmailPage {
    private static final By EMAIL_ON_ACCOUNT_ICON_LOCATOR = By.xpath("//div [@class='gb_yb']/div[@class='gb_Db']");
    private static final By SIGN_OUT_BUTTON_LOCATOR = By.xpath("//a[@id='gb_71'][text()='Sign out']");

    public AccountPage() {
        super();
    }

    public PasswordPage signOutButtonClick() {
        waitForElementVisible(SIGN_OUT_BUTTON_LOCATOR);
        driver.findElement(SIGN_OUT_BUTTON_LOCATOR).click();
        return new PasswordPage();
    }

    public static By getEmailOnAccountIconLocator() {
        return EMAIL_ON_ACCOUNT_ICON_LOCATOR;
    }

    public static By getSignOutButtonLocator() {
        return SIGN_OUT_BUTTON_LOCATOR;
    }
}
