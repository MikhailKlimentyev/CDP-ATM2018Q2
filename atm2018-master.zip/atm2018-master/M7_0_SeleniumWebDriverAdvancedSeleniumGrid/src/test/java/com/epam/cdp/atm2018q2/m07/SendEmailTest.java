/**
 * SendEmailTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/28/2018
 */

package com.epam.cdp.atm2018q2.m07;

import com.epam.cdp.atm2018q2.m07.pages.DraftEmailPage;
import com.epam.cdp.atm2018q2.m07.pages.GmailPage;
import com.epam.cdp.atm2018q2.m07.pages.LoginPage;
import com.epam.cdp.atm2018q2.m07.utils.GlobalConstants;
import com.epam.cdp.atm2018q2.m07.utils.WebDriverSingleton;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

public class SendEmailTest {

    @Test(description = "Send email, verify that drafted email's count is decreased after email sending.")
    public void verifyThatEmailDeletedFromDraftsAfterSending() throws InterruptedException {
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(GlobalConstants.getLOGIN()).nextButtonClick().
                fillPasswordInput(GlobalConstants.getPASSWORD()).nextButtonClick().composeButtonClick().popOutButtonClick().
                toInputSendKeys(GlobalConstants.getToInputText()).subjectInputSendKeys(GlobalConstants.getSubjectInputText()).
                bodyInputSendKeys(GlobalConstants.getBodyInputText()).closeButtonClick();
        int initialDraftsNumber = gmailPage.getDraftsNumber();
        gmailPage.draftsIconClick().draftEmailCheckboxClick().draftLabelClick().sendButtonClick();
        Thread.sleep(1000);
        int finalDraftsNumber = gmailPage.getDraftsNumber();
        Assert.assertEquals(finalDraftsNumber, initialDraftsNumber - 1, "Sent Email was not deleted from 'Drafts' folder");
        gmailPage.accountIconClick().signOutButtonClick();
    }

    @Test(description = "Send email, verify that sent email header equals to text inputted into email header")
    public void verifyThatSubjectOfSentEmailIsCorrectTest() throws InterruptedException {
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(GlobalConstants.getLOGIN()).nextButtonClick().
                fillPasswordInput(GlobalConstants.getPASSWORD()).nextButtonClick();

        String sentEmailHeader = gmailPage.composeButtonClick().popOutButtonClick().
                toInputSendKeys(GlobalConstants.getToInputText()).subjectInputSendKeys(GlobalConstants.getSubjectInputText()).
                bodyInputSendKeys(GlobalConstants.getBodyInputText()).closeButtonClick().draftsIconClick().
                draftEmailCheckboxClick().draftLabelClick().sendButtonClick().sentMailIconClick().getHeaderText();
        Assert.assertEquals(sentEmailHeader, GlobalConstants.getSubjectInputText(), "Email was not sent");
        gmailPage.accountIconClick().signOutButtonClick();
    }

    @AfterMethod(description = "Close browser, kill webdriver")
    public void kill() {
        WebDriverSingleton.kill();
    }
}
