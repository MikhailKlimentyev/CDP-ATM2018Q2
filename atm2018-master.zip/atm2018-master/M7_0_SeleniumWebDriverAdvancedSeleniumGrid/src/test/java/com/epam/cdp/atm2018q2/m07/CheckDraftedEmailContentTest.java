/**
 * CheckDraftedEmailContentTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/28/2018
 */

package com.epam.cdp.atm2018q2.m07;

import com.epam.cdp.atm2018q2.m07.pages.DraftEmailPage;
import com.epam.cdp.atm2018q2.m07.pages.GmailPage;
import com.epam.cdp.atm2018q2.m07.pages.LoginPage;
import com.epam.cdp.atm2018q2.m07.utils.GlobalConstants;
import com.epam.cdp.atm2018q2.m07.utils.WebDriverSingleton;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

public class CheckDraftedEmailContentTest {

    @Test(description = "Compare 'To' field content of composed email and drafted email")
    public void checkToInputContentOfDraftedEmailTest() {
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(GlobalConstants.getLOGIN()).nextButtonClick().
                fillPasswordInput(GlobalConstants.getPASSWORD()).nextButtonClick().composeButtonClick().popOutButtonClick().
                toInputSendKeys(GlobalConstants.getToInputText()).subjectInputSendKeys(GlobalConstants.getSubjectInputText()).
                bodyInputSendKeys(GlobalConstants.getBodyInputText()).closeButtonClick();
        DraftEmailPage draftEmailPage = gmailPage.draftsIconClick().draftEmailCheckboxClick().draftLabelClick();
        Assert.assertEquals(draftEmailPage.getToInputText(), GlobalConstants.getToInputText(), "Text in 'To' field of drafted email is not valid");
        gmailPage.accountIconClick().signOutButtonClick();
    }

    @Test(description = "Compare 'Subject' field content of composed email and drafted email")
    public void checkSubjectInputContentOfDraftedEmailTest() {
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(GlobalConstants.getLOGIN()).nextButtonClick().
                fillPasswordInput(GlobalConstants.getPASSWORD()).nextButtonClick().composeButtonClick().popOutButtonClick().
                toInputSendKeys(GlobalConstants.getToInputText()).subjectInputSendKeys(GlobalConstants.getSubjectInputText()).
                bodyInputSendKeys(GlobalConstants.getBodyInputText()).closeButtonClick();
        DraftEmailPage draftEmailPage = gmailPage.draftsIconClick().draftEmailCheckboxClick().draftLabelClick();
        Assert.assertEquals(draftEmailPage.getSubjectInputText(), GlobalConstants.getSubjectInputText(), "Text in 'Subject' field of drafted email is not valid");
        gmailPage.accountIconClick().signOutButtonClick();
    }

    @Test(description = "Compare 'Body' field content of composed email and drafted email")
    public void checkBodyInputContentOfDraftedEmailTest() {
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(GlobalConstants.getLOGIN()).nextButtonClick().
                fillPasswordInput(GlobalConstants.getPASSWORD()).nextButtonClick().composeButtonClick().popOutButtonClick().
                toInputSendKeys(GlobalConstants.getToInputText()).subjectInputSendKeys(GlobalConstants.getSubjectInputText()).
                bodyInputSendKeys(GlobalConstants.getBodyInputText()).closeButtonClick();
        DraftEmailPage draftEmailPage = gmailPage.draftsIconClick().draftEmailCheckboxClick().draftLabelClick();
        Assert.assertEquals(draftEmailPage.getBodyInputText(), GlobalConstants.getBodyInputText(), "Text in 'Body' field of drafted email is not valid");
        gmailPage.accountIconClick().signOutButtonClick();
    }

    @Test(description = "Compare Header content of composed email and drafted email")
    public void checkHeaderContentOfDraftedEmailTest() {
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(GlobalConstants.getLOGIN()).nextButtonClick().
                fillPasswordInput(GlobalConstants.getPASSWORD()).nextButtonClick().composeButtonClick().popOutButtonClick().
                toInputSendKeys(GlobalConstants.getToInputText()).subjectInputSendKeys(GlobalConstants.getSubjectInputText()).
                bodyInputSendKeys(GlobalConstants.getBodyInputText()).closeButtonClick();
        DraftEmailPage draftEmailPage = gmailPage.draftsIconClick().draftEmailCheckboxClick().draftLabelClick();
        Assert.assertEquals(draftEmailPage.getHeaderText(), GlobalConstants.getSubjectInputText(), "Text of Header of drafted email is not valid");
        gmailPage.accountIconClick().signOutButtonClick();
    }

    @AfterMethod(description = "Close browser, kill webdriver")
    public void kill() {
        WebDriverSingleton.kill();
    }
}
