/**
 * ComposeEmailTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/28/2018
 */

package com.epam.cdp.atm2018q2.m07;

import com.epam.cdp.atm2018q2.m07.pages.AccountPage;
import com.epam.cdp.atm2018q2.m07.pages.GmailPage;
import com.epam.cdp.atm2018q2.m07.pages.LoginPage;
import com.epam.cdp.atm2018q2.m07.utils.GlobalConstants;
import com.epam.cdp.atm2018q2.m07.utils.WebDriverSingleton;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

public class ComposeEmailTest {

    @Test(description = "Compose Email, close Email without sending, verify that composed email presents in drafts folder")
    public void verifyThatComposedEmailSavedInDraftsFolderTest() {
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(GlobalConstants.getLOGIN()).nextButtonClick().fillPasswordInput(GlobalConstants.getPASSWORD()).nextButtonClick();
        int initialDraftsNumber = gmailPage.getDraftsNumber();
        System.out.println("composeEmailTest\ninitialDraftsNumber: " + initialDraftsNumber);
        gmailPage.composeButtonClick().popOutButtonClick().toInputSendKeys(GlobalConstants.getToInputText()).subjectInputSendKeys(GlobalConstants.getSubjectInputText()).
                bodyInputSendKeys(GlobalConstants.getBodyInputText()).closeButtonClick();
        int finalDraftsNumber = gmailPage.getDraftsNumber();
        System.out.println("finalDraftsNumber: " + finalDraftsNumber);
        Assert.assertTrue(finalDraftsNumber == initialDraftsNumber + 1, "Email was not added to 'Drafts' folder");
        gmailPage.accountIconClick().signOutButtonClick();
    }

    @AfterMethod(description = "Close browser, kill webdriver")
    public void kill() {
        WebDriverSingleton.kill();
    }
}
