/**
 * DeleteSentEmailTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/29/2018
 */

package com.epam.cdp.atm2018q2.m07;

import com.epam.cdp.atm2018q2.m07.pages.GmailPage;
import com.epam.cdp.atm2018q2.m07.pages.LoginPage;
import com.epam.cdp.atm2018q2.m07.utils.GlobalConstants;
import com.epam.cdp.atm2018q2.m07.utils.WebDriverSingleton;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

public class DeleteDraftEmailTest {
    @Test(description = "Delete email from Draft folder using JS context click, verify that Drafts count decreased")
    public void verifyThatDraftedEmailDeletedTest() {
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(GlobalConstants.getLOGIN()).nextButtonClick().
                fillPasswordInput(GlobalConstants.getPASSWORD()).nextButtonClick().composeButtonClick().popOutButtonClick().
                toInputSendKeys(GlobalConstants.getToInputText()).subjectInputSendKeys(GlobalConstants.getSubjectInputText()).
                bodyInputSendKeys(GlobalConstants.getBodyInputText()).closeButtonClick();
        int initialDraftsNumber = gmailPage.getDraftsNumber();
        System.out.println("DeleteDraftEmailTest\ninitialDraftsNumber: " + initialDraftsNumber);
        gmailPage.draftsIconClick().draftEmailCheckboxContextMenuCall();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        int finalDraftsNumber = gmailPage.getDraftsNumber();
        System.out.println("finalDraftsNumber: " + finalDraftsNumber);
        Assert.assertTrue(finalDraftsNumber == initialDraftsNumber - 1, "Email was not deleted from 'Drafts' folder");
        gmailPage.accountIconClick().signOutButtonClick();
    }

    @Test(description = "Move drafred emails to 'Trash' folder via drag and drop action, verify that Drafts count decreased")
    public void moveDrafredEmailsToTrashFolder() {
        GmailPage gmailPage = new LoginPage().open().fillLoginInput(GlobalConstants.getLOGIN()).nextButtonClick().
                fillPasswordInput(GlobalConstants.getPASSWORD()).nextButtonClick();
        for (int i = 0; i < 3; i++) {
            gmailPage.composeButtonClick().popOutButtonClick().toInputSendKeys(GlobalConstants.getToInputText()).subjectInputSendKeys(GlobalConstants.getSubjectInputText()).
                    bodyInputSendKeys(GlobalConstants.getBodyInputText()).closeButtonClick();
        }
        int initialDraftsNumber = gmailPage.getDraftsNumber();
        System.out.println("DeleteDraftEmailTest\ninitialDraftsNumber: " + initialDraftsNumber);
        gmailPage.draftsIconClick().multiClickCheckboxes().openMoreDropDown().dragAndDropDraftedEmailsToTrashFolder();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        int finalDraftsNumber = gmailPage.getDraftsNumber();
        System.out.println("finalDraftsNumber: " + finalDraftsNumber);
        Assert.assertTrue(finalDraftsNumber == initialDraftsNumber - 3, "Email was not deleted from 'Drafts' folder");
        gmailPage.accountIconClick().signOutButtonClick();
    }

    @AfterMethod(description = "Close browser, kill webdriver")
    public void kill() {
        WebDriverSingleton.kill();
    }
}
