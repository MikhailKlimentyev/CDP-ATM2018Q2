/**
 * AutomationPracticeTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/15/2018
 */

package com.epam.cdp.atm2018q2.m06.po;

import com.epam.cdp.atm2018q2.m06.po.pages.FilterResultsPage;
import com.epam.cdp.atm2018q2.m06.po.pages.MenuPage;
import com.epam.cdp.atm2018q2.m06.po.pages.SortResultPage;
import com.epam.cdp.atm2018q2.m06.po.pages.WomenPage;
import com.epam.cdp.atm2018q2.m06.utils.WebDriverSingleton;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class AutomationPracticeTest {
//    private WebDriver driver;
////    private static final String CHROME_WEB_DRIVER_HOME = "src\\main\\resources\\chromedriver.exe";
//
////    @BeforeClass(description = "Start browser")
////    private void initBrowser() {
////        System.setProperty("webdriver.chrome.driver", CHROME_WEB_DRIVER_HOME);
////        driver = new ChromeDriver();
////        driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
////        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
////        driver.manage().window().maximize();
////    }

    @Test(description = "Test filtering of products by colors")
    private void filterByColorsTest() {
        WomenPage womenPage = new MenuPage().open().navigateToWomenTab();
        FilterResultsPage filterResultsPage = womenPage.filterByColor();
        Assert.assertEquals(filterResultsPage.getCountOfColorsAddedToEnabledFilters(), 1, "Colors added into Enabled filters don't equal 1");
        Assert.assertEquals(filterResultsPage.getNameOfFirstColorAddedToEnabledFilters(), womenPage.getColorName(), "Color name added " + "into Enabled filters is not matched to selected color");
        Assert.assertEquals(filterResultsPage.getCountOfFilteredProducts(), womenPage.getNumberOfDressesForColor(), "Incorrect number of" + " filtered products by color");
        Assert.assertTrue(filterResultsPage.compareColorOfFilteredProductByFilteredColor(womenPage.getColorName()), "Colors are not matched");
        Assert.assertTrue(filterResultsPage.compareNumberOfFilteredProductByNumberSpecifiedOnTheButton(womenPage.getNumberOfDressesForColor()), "Numbers are not matched");
    }

    @Test(description = "Test sorting by descend price of products filtered by colors ", dependsOnMethods = "filterByColorsTest")
    private void sortByPriceDescendTest() {
        FilterResultsPage filterResultsPage = new FilterResultsPage();
        SortResultPage sortResultPage = filterResultsPage.sortByHighestFirstPrice();
        System.out.println("Actual: ");
        ArrayList<Double> actual = sortResultPage.getPricesOfFilteredProducts();
        for (int i = 0; i < actual.size(); i++) {
            System.out.println("Index: " + i + " " + actual.get(i));
        }
        ArrayList<Double> expected = new ArrayList<Double>(actual);
        Collections.sort(expected, Collections.reverseOrder());
        System.out.println("\nExpected: ");
        for (int j = 0; j < expected.size(); j++) {
            System.out.println("Index: " + j + " " + expected.get(j));
        }
        Assert.assertEquals(actual, expected);
    }

    @AfterClass(description = "Close browser")
    private void kill() {
        WebDriverSingleton.kill();
    }
}
