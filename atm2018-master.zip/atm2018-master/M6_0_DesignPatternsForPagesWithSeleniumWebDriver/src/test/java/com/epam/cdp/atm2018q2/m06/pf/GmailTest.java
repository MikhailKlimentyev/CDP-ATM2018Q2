/**
 * GmailTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/21/2018
 */

package com.epam.cdp.atm2018q2.m06.pf;

import com.epam.cdp.atm2018q2.m06.pf.pages.*;
import com.epam.cdp.atm2018q2.m06.utils.WebDriverSingleton;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

public class GmailTest {

    //Credentials
    private static final String LOGIN = "foratm2018q@gmail.com";
    private static final String PASSWORD = "atm2018q";

    @Test(description = "Login to gmail.com")
    public void authTest() {
        AccountPage accountPage = new LoginPage().open().fillLoginInput(LOGIN).nextButtonClick().fillPasswordInput(PASSWORD).nextButtonClick().accountIconClick();
        Assert.assertTrue(accountPage.isElementPresent(accountPage.getEmailOnAccountIcon()), "Email label was not found on the account icon.");
        Assert.assertTrue(accountPage.isElementPresent(accountPage.getSignOutButton()), "'Sign out' button was not found on the account icon.");
    }

    @Test(description = "Compose Email, close Email without sending, verify that composed email presents in drafts folder", dependsOnMethods = "authTest")
    public void composeEmailTest() {
        int initialDraftsNumber = new GmailPage().getDraftsNumber();
        System.out.println("composeEmailTest\ninitialDraftsNumber: " + initialDraftsNumber);
        new GmailPage().composeButtonClick().popOutButtonClick().toInputSendKeys().subjectInputSendKeys().bodyInputSendKeys().closeButtonClick();
        int finalDraftsNumber = new GmailPage().getDraftsNumber();
        System.out.println("finalDraftsNumber: " + finalDraftsNumber);
        Assert.assertTrue(finalDraftsNumber == initialDraftsNumber + 1, "Email was not added to 'Drafts' folder");
    }

    @Test(description = "Compare composed email's drafted email's content", dependsOnMethods = "composeEmailTest")
    public void compareDraftedEmailContentTest() {
        DraftEmailPage draftEmailPage = new GmailPage().draftsIconClick().draftEmailCheckboxClick().draftLabelClick();
        EmailPage emailPage = new EmailPage();
        Assert.assertEquals(draftEmailPage.getToInputText(), emailPage.getToInputText(), "Text in 'To' field of drafted email is not valid");
        Assert.assertEquals(draftEmailPage.getSubjectInputText(), emailPage.getSubjectInputText(), "Text in 'Subject' field of drafted email is not valid");
        Assert.assertEquals(draftEmailPage.getBodyInputText(), emailPage.getBodyInputText(), "Text in 'Body' field of drafted email is not valid");
        Assert.assertEquals(draftEmailPage.getHeaderText(), emailPage.getSubjectInputText(), "Text of Header of drafted email is not valid");
    }

    @Test(description = "Send email, verify that the mail disappeared from ‘Drafts’ folder, verify that the mail is in ‘Sent’ folder.", dependsOnMethods = "compareDraftedEmailContentTest")
    public void sendEmailTest() throws InterruptedException {
        GmailPage gmailPage = new GmailPage();
        int initialDraftsNumber = gmailPage.getDraftsNumber();
        System.out.println("\nsendEmailTest\ninitialDraftsNumber: " + initialDraftsNumber);
        String sentEmailHeader = new DraftEmailPage().sendButtonClick().sentMailIconClick().getHeaderText();
        Thread.sleep(1000);
        int finalDraftsNumber = gmailPage.getDraftsNumber();
        System.out.println("finalDraftsNumber: " + finalDraftsNumber);
        Assert.assertEquals(finalDraftsNumber, initialDraftsNumber - 1, "Sent Email was not deleted from 'Drafts' folder");
        Assert.assertEquals(sentEmailHeader, new EmailPage().getSubjectInputText(), "Email was not sent");
    }

    @Test(description = "Log out", dependsOnMethods = "sendEmailTest")
    public void doLogOutTest() {
        PasswordPage passwordPage = new GmailPage().accountIconClick().SignOutButtonClick();
        if (passwordPage.isAlertPresent()) {
            Alert logOutConfirmation = WebDriverSingleton.getWebDriverInstance().switchTo().alert();
            logOutConfirmation.accept();
        }
        Assert.assertTrue(passwordPage.isElementPresent(passwordPage.getHeadingText()), "Sign out was not made");
    }

    @AfterClass(description = "Close browser")
    public void kill() {
        WebDriverSingleton.kill();
    }
}
