/**
 * PasswordPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/21/2018
 */

package com.epam.cdp.atm2018q2.m06.pf.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PasswordPage extends AbstractPage {
    public PasswordPage() {
        super();
    }

    @FindBy(xpath = "//input[@type='password'][@name='password']")
    WebElement passwordInput;

    @FindBy(xpath = "//div[@id='passwordNext']")
    WebElement nextButton;

    @FindBy(xpath = "//h1[@id='headingText']")
    WebElement headingText;

    public PasswordPage fillPasswordInput(String password) {
        waitForElementVisible(passwordInput);
        passwordInput.sendKeys(password);
        return this;
    }

    public GmailPage nextButtonClick() {
        waitForElementVisible(nextButton);
        nextButton.click();
        return new GmailPage();
    }

    public WebElement getHeadingText() {
        waitForElementVisible(headingText);
        return headingText;
    }
}
