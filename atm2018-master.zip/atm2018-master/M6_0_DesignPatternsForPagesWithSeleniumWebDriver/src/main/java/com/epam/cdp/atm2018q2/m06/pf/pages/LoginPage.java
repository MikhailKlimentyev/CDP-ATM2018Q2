/**
 * AuthorizationPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/21/2018
 */

package com.epam.cdp.atm2018q2.m06.pf.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends AbstractPage {
    public LoginPage() {
        super();
    }

    @FindBy(xpath = "//input[@type='email'][@class='whsOnd zHQkBf'][@autocomplete='username']")
    WebElement loginInput;

    @FindBy(xpath = "//div[@id='identifierNext'][@role='button']")
    WebElement nextButton;

    public LoginPage open() {
        driver.get("https://mail.google.com");
        return this;
    }

    public LoginPage fillLoginInput(String login) {
        waitForElementVisible(loginInput);
        loginInput.sendKeys(login);
        return this;
    }

    public PasswordPage nextButtonClick() {
        waitForElementVisible(nextButton);
        nextButton.click();
        return new PasswordPage();
    }
}
