/**
 * DraftsPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/22/2018
 */

package com.epam.cdp.atm2018q2.m06.pf.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class DraftsPage extends AbstractPage {
    public DraftsPage() {
        super();
    }

    @FindBy(xpath = "//div[@class='yW']/font[text()='Draft']")
    WebElement draftLabel;

    @FindBy(xpath = "//div[@class='ae4 UI']/div[@class='Cp']/div/table[@class='F cf zt']/tbody/tr[@class='zA yO']/td[@class='oZ-x3 xY']/div/div[1]")
    WebElement draftEmailCheckbox;

    public DraftEmailPage draftLabelClick() {
        waitForElementVisible(draftLabel);
        draftLabel.click();
        return new DraftEmailPage();
    }

    public DraftsPage draftEmailCheckboxClick() {
        waitForElementVisible(draftEmailCheckbox);
        draftEmailCheckbox.click();
        return this;
    }
}