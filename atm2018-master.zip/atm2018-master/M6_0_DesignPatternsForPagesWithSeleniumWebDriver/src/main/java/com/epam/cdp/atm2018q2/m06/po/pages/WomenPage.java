/**
 * WomenPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/15/2018
 */

package com.epam.cdp.atm2018q2.m06.po.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WomenPage extends AbstractPage {
    private static final By YELLOW_COLOR_BUTTON_LOCATOR = By.xpath("//input[@id='layered_id_attribute_group_16']");
    private static final By YELLOW_COLOR_LOCATOR = By.xpath("//label[@class='layered_color'][@rel='16_3']/a[text()='Yellow']");
    private static final By YELLOW_COUNT_LOCATOR = By.xpath("//label[@class='layered_color'][@rel='16_3']/a[text()='Yellow']/span");

//    public WomenPage(WebDriver driver) {
//        super(driver);
//    }

    public FilterResultsPage filterByColor() {
        waitForElementVisible(YELLOW_COLOR_BUTTON_LOCATOR);
        driver.findElement(YELLOW_COLOR_BUTTON_LOCATOR).click();
        return new FilterResultsPage();
    }

    public String getColorName() {
        waitForElementVisible(YELLOW_COLOR_LOCATOR);
        return driver.findElement(YELLOW_COLOR_LOCATOR).getText().substring(0, driver.findElement(YELLOW_COLOR_LOCATOR).getText().indexOf(" ("));
    }

    public int getNumberOfDressesForColor() {
        Pattern pattern = Pattern.compile("\\d+");
        waitForElementVisible(YELLOW_COUNT_LOCATOR);
        Matcher matcher = pattern.matcher(driver.findElement(YELLOW_COUNT_LOCATOR).getText());
        int colorCount = 0;
        while (matcher.find()) {
            String draftsIconNumber = driver.findElement(YELLOW_COUNT_LOCATOR).getText().substring(matcher.start(), matcher.end());
            colorCount = Integer.parseInt(draftsIconNumber);
        }
        return colorCount;
    }

}
