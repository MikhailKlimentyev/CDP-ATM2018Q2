/**
 * SortResultPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/15/2018
 */

package com.epam.cdp.atm2018q2.m06.po.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

public class SortResultPage extends AbstractPage {

    private static final By FILTERED_PRODUCT_LIST_LOCATOR = By.xpath("//div[@id='center_column']");
    private static final By ITEM_IN_FILTERED_PRODUCT_LIST_LOCATOR = By.xpath(".//ul[@class='product_list grid row']/li");
    public static final By PRICE_LOCATOR = By.xpath(".//div[@class='product-container']/div[@class='right-block']/div[@class='content_price']/span[@class='price product-price']");

//    public SortResultPage(WebDriver driver) {
//        super(driver);
//    }

    public ArrayList<Double> getPricesOfFilteredProducts() {
        ArrayList<Double> pricesOfSortedProducts = new ArrayList<Double>();
        waitForElementVisible(FILTERED_PRODUCT_LIST_LOCATOR);
        WebElement filteredProductList = driver.findElement(FILTERED_PRODUCT_LIST_LOCATOR);
        waitForElementVisible(ITEM_IN_FILTERED_PRODUCT_LIST_LOCATOR);
        List<WebElement> productsFilteredByColor = filteredProductList.findElements(ITEM_IN_FILTERED_PRODUCT_LIST_LOCATOR);
        for (WebElement productFilteredByColor : productsFilteredByColor) {
            double price = Double.parseDouble(productFilteredByColor.findElement(PRICE_LOCATOR).getText().substring(1));
            pricesOfSortedProducts.add(price);
        }
        return pricesOfSortedProducts;
    }
}
