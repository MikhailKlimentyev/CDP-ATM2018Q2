/**
 * MessagePage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/21/2018
 */

package com.epam.cdp.atm2018q2.m06.pf.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class EmailPage extends AbstractPage {
    public EmailPage() {
        super();
    }

    //Text for Inputs
    private static final String TO_INPUT_TEXT = "Mikhail Klimentsyev";
    private static final String SUBJECT_INPUT_TEXT = "Text to test subject input";
    private static final String BODY_INPUT_TEXT = "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. " + "Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, " + "nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat " + "massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, " + "imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. " + "Vivamus elementum semper nisi. \n\n" + "Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, " + "consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. " + "Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. " + "Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, " + "sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, " + "hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. \n\n" + "Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. " + "Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc.\n\n\n\n" + "Best Regards,\n\n" + "Mikhail Klimentsyeu\n" + "Software Testing Engineer";

    @FindBy(xpath = "//table[@class='cf Ht']/tbody/tr/td[@class='Hm']/img[@class='Hq aUG']")
    WebElement popOutButton;

    @FindBy(xpath = "//div[@class='wO nr l1']/textarea[@class='vO'][@role='combobox']")
    WebElement toInput;

    @FindBy(xpath = "//div[@class='aoD az6']/input[@name='subjectbox'][@class='aoT']")
    WebElement subjectInput;

    @FindBy(xpath = "//div[@class='Am Al editable LW-avf'][@role='textbox']")
    WebElement bodyInput;

    @FindBy(xpath = "//img[@class='Ha'][@alt='Close']")
    WebElement closeButton;

    public EmailPage popOutButtonClick() {
        waitForElementVisible(popOutButton);
        popOutButton.click();
        return this;
    }

    public EmailPage toInputSendKeys() {
        waitForElementVisible(toInput);
        toInput.sendKeys(TO_INPUT_TEXT, Keys.RETURN);
        return this;
    }

    public EmailPage subjectInputSendKeys() {
        waitForElementVisible(subjectInput);
        subjectInput.sendKeys(SUBJECT_INPUT_TEXT);
        return this;
    }

    public EmailPage bodyInputSendKeys() {
        waitForElementVisible(bodyInput);
        bodyInput.sendKeys(BODY_INPUT_TEXT);
        return this;
    }

    public GmailPage closeButtonClick() {
        waitForElementVisible(closeButton);
        closeButton.click();
        return new GmailPage();
    }

    public static String getToInputText() {
        return TO_INPUT_TEXT;
    }

    public static String getSubjectInputText() {
        return SUBJECT_INPUT_TEXT;
    }

    public static String getBodyInputText() {
        return BODY_INPUT_TEXT;
    }
}
