/**
 * DraftEmailPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/22/2018
 */

package com.epam.cdp.atm2018q2.m06.pf.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class DraftEmailPage extends AbstractPage {
    public DraftEmailPage() {
        super();
    }

    @FindBy(xpath = "//div[@class='oL aDm az9']/span")
    WebElement toInput;

    @FindBy(xpath = "//form[@class='bAs']//input[@name='subject']")
    WebElement subjectInput;

    @FindBy(xpath = "//div[@class='Am Al editable LW-avf']")
    WebElement bodyInput;

    @FindBy(xpath = "//div[@class='Hp']/h2[@class='a3E']/div[@class='aYF']")
    WebElement header;

    @FindBy(xpath = "//div[@class='J-J5-Ji btA']/div[@role='button'][text()='Send']")
    WebElement sendButton;

    public String getToInputText() {
        return toInput.getText();
    }

    public String getSubjectInputText() {
        return subjectInput.getAttribute("value");
    }

    public String getBodyInputText() {
        return bodyInput.getText();
    }

    public String getHeaderText() {
        return header.getText();
    }

    public GmailPage sendButtonClick(){
        waitForElementVisible(sendButton);
        sendButton.click();
        return new GmailPage();
    }
}