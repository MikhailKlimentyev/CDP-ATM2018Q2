/**
 * AccountPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/21/2018
 */

package com.epam.cdp.atm2018q2.m06.pf.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AccountPage extends AbstractPage {
    public AccountPage() {
        super();
    }

    @FindBy(xpath = "//div [@class='gb_yb']/div[@class='gb_Db']")
    WebElement emailOnAccountIcon;

    @FindBy(xpath = "//a[@id='gb_71'][text()='Sign out']")
    WebElement signOutButton;

    public WebElement getEmailOnAccountIcon() {
        waitForElementVisible(emailOnAccountIcon);
        return emailOnAccountIcon;
    }

    public WebElement getSignOutButton() {
        waitForElementVisible(signOutButton);
        return signOutButton;
    }

    public PasswordPage SignOutButtonClick(){
        waitForElementVisible(signOutButton);
        signOutButton.click();
        return new PasswordPage();
    }
}
