/**
 * SentEmailPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/22/2018
 */

package com.epam.cdp.atm2018q2.m06.pf.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SentEmailPage extends AbstractPage {
    public SentEmailPage() {
        super();
    }

    @FindBy(xpath = "//div[1][@class='y6']/span[@class='bog'][1]")
    WebElement emailHeader;

    public String getHeaderText() {
        return emailHeader.getAttribute("textContent");
    }
}
