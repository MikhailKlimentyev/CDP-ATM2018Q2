/**
 * MenuPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/15/2018
 */

package com.epam.cdp.atm2018q2.m06.po.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class MenuPage extends AbstractPage {
    private static final String URL = "http://automationpractice.com";
    private static final By WOMEN_TAB_LOCATOR = By.xpath("//a[@class='sf-with-ul'][@title='Women']");

//    public MenuPage(WebDriver driver) {
//        super(driver);
//    }

    public MenuPage open() {
        driver.get(URL);
        return this;
    }

    public WomenPage navigateToWomenTab(){
        waitForElementVisible(WOMEN_TAB_LOCATOR);
        driver.findElement(WOMEN_TAB_LOCATOR).click();
        return new WomenPage();
    }
}
