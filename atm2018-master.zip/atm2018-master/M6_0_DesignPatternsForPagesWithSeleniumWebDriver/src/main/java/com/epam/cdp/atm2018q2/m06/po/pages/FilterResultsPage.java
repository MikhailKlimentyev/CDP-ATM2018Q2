/**
 * FilterResultsPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/15/2018
 */

package com.epam.cdp.atm2018q2.m06.po.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

public class FilterResultsPage extends AbstractPage {
    private static final By ENABLED_FILTERS_LOCATOR = By.xpath("//div[@id='enabled_filters']");
    private static final By ITEM_IN_ENABLED_FILTERS_LOCATOR = By.xpath(".//ul/li");
    private static final By FILTERED_PRODUCT_LIST_LOCATOR = By.xpath("//div[@id='center_column']");
    private static final By ITEM_IN_FILTERED_PRODUCT_LIST_LOCATOR = By.xpath(".//ul[@class='product_list grid row']/li");
    private static final By COLORS_IN_FILTERED_PRODUCT_LOCATOR = By.xpath(".//div[@class='product-container']/div[@class='right-block']/div[@class='color-list-container']/ul[@class='color_to_pick_list clearfix']/li");
    private static final By LINK_FOR_COLORS_IN_FILTERED_PRODUCT_LOCATOR = By.xpath("./a[@class='color_pick']");
    private static final By PRODUCT_COUNT_LABEL_LOCATOR = By.xpath("//div[@class='top-pagination-content clearfix']//div[@class='product-count']");
    public static final By PRODUCT_SORT_LOCATOR = By.xpath("//select[@id='selectProductSort']");

//    public FilterResultsPage(WebDriver driver) {
//        super(driver);
//    }

    public int getCountOfColorsAddedToEnabledFilters() {
        WebElement enabledFilters = driver.findElement(ENABLED_FILTERS_LOCATOR);
        waitForElementPresent(ITEM_IN_ENABLED_FILTERS_LOCATOR);
        List<WebElement> enabledColors = enabledFilters.findElements(ITEM_IN_ENABLED_FILTERS_LOCATOR);
        return enabledColors.size();
    }

    public String getNameOfFirstColorAddedToEnabledFilters() {
        WebElement enabledFilters = driver.findElement(ENABLED_FILTERS_LOCATOR);
        waitForElementPresent(ITEM_IN_ENABLED_FILTERS_LOCATOR);
        List<WebElement> enabledColors = enabledFilters.findElements(ITEM_IN_ENABLED_FILTERS_LOCATOR);
        return enabledColors.get(0).getText().substring(7);
    }

    public int getCountOfFilteredProducts() {
        waitForElementVisible(FILTERED_PRODUCT_LIST_LOCATOR);
        WebElement filteredProductList = driver.findElement(FILTERED_PRODUCT_LIST_LOCATOR);
        waitForElementVisible(ITEM_IN_FILTERED_PRODUCT_LIST_LOCATOR);
        List<WebElement> productsFilteredByColor = filteredProductList.findElements(ITEM_IN_FILTERED_PRODUCT_LIST_LOCATOR);
        return productsFilteredByColor.size();
    }

    public boolean compareColorOfFilteredProductByFilteredColor(String color) {
        waitForElementVisible(FILTERED_PRODUCT_LIST_LOCATOR);
        WebElement filteredProductList = driver.findElement(FILTERED_PRODUCT_LIST_LOCATOR);
        waitForElementVisible(ITEM_IN_FILTERED_PRODUCT_LIST_LOCATOR);
        List<WebElement> productsFilteredByColor = filteredProductList.findElements(ITEM_IN_FILTERED_PRODUCT_LIST_LOCATOR);
        int countOfColorMatches;
        for (WebElement productFilteredByColor : productsFilteredByColor) {
            countOfColorMatches = 0;
            waitForElementVisible(COLORS_IN_FILTERED_PRODUCT_LOCATOR);
            List<WebElement> colorsInFilteredProduct = productFilteredByColor.findElements(COLORS_IN_FILTERED_PRODUCT_LOCATOR);
            for (WebElement colorInFilteredProduct : colorsInFilteredProduct) {
                String linkValue = colorInFilteredProduct.findElement(LINK_FOR_COLORS_IN_FILTERED_PRODUCT_LOCATOR).getAttribute("href");
                String trimmedLinkValue = linkValue.substring(linkValue.indexOf("color-") + 6);
                if (trimmedLinkValue.equalsIgnoreCase(color)) {
                    countOfColorMatches++;
                }
            }
            if (countOfColorMatches != 1) {
                return false;
            }
        }
        return true;
    }

    public boolean compareNumberOfFilteredProductByNumberSpecifiedOnTheButton(int numberSpecifiedOnTheButton) {
        waitForElementVisible(PRODUCT_COUNT_LABEL_LOCATOR);
        String productCountText = driver.findElement(PRODUCT_COUNT_LABEL_LOCATOR).getText();
        String firstNumberToCompare = productCountText.substring(productCountText.indexOf("- ") + 2, productCountText.indexOf(" of"));
        String secondNumberToCompare = productCountText.substring(productCountText.indexOf("of ") + 3, productCountText.indexOf(" items"));
        if (Integer.parseInt(firstNumberToCompare) == numberSpecifiedOnTheButton && Integer.parseInt(secondNumberToCompare) == numberSpecifiedOnTheButton) {
            return true;
        } else {
            return false;
        }
    }

    public SortResultPage sortByHighestFirstPrice(){
        Select sortBy = new Select(driver.findElement(PRODUCT_SORT_LOCATOR));
        sortBy.selectByValue("price:desc");
        return new SortResultPage();
    }



}
