/**
 * GmailPage.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/21/2018
 */

package com.epam.cdp.atm2018q2.m06.pf.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GmailPage extends AbstractPage {
    public GmailPage() {
        super();
    }

    @FindBy(xpath = "//a[@class='gb_b gb_db gb_R'][@role='button']")
    WebElement accountIcon;

    @FindBy(xpath = "//div[@class='T-I J-J5-Ji T-I-KE L3'][@role='button']")
    WebElement composeButton;

    @FindBy(xpath = "//a[@class='J-Ke n0'][contains(text(), 'Drafts')]")
    WebElement draftsIcon;

    @FindBy(xpath = "//a[@class='J-Ke n0'][contains(text(), 'Sent Mail')]")
    WebElement sentMailIcon;

    public AccountPage accountIconClick() {
        waitForElementVisible(accountIcon);
        accountIcon.click();
        return new AccountPage();
    }

    public EmailPage composeButtonClick() {
        waitForElementVisible(composeButton);
        composeButton.click();
        return new EmailPage();
    }

    public DraftsPage draftsIconClick() {
        waitForElementVisible(draftsIcon);
        draftsIcon.click();
        return new DraftsPage();
    }

    public int getDraftsNumber() {
        waitForElementVisible(draftsIcon);
        String draftsIconText = draftsIcon.getText();
        Pattern pattern = Pattern.compile("\\d+");
        Matcher matcher = pattern.matcher(draftsIconText);
        int draftsNumber = 0;
        while (matcher.find()) {
            String draftsIconNumber = draftsIconText.substring(matcher.start(), matcher.end());
            draftsNumber = Integer.parseInt(draftsIconNumber);
        }
        return draftsNumber;
    }

    public SentEmailPage sentMailIconClick() {
        waitForElementVisible(sentMailIcon);
        sentMailIcon.click();
        return new SentEmailPage();
    }
}
