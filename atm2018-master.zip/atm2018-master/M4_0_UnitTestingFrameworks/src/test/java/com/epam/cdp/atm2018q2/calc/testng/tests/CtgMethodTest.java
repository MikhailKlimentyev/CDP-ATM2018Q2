/**
 * CtgMethodTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 6/24/2018
 */

package com.epam.cdp.atm2018q2.calc.testng.tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class CtgMethodTest extends BaseTest {

    @Test(dataProvider = "valuesForCtgMethodTest")
    public void testCtgWhenCtgGetNumberThenReturnCotangentFromIt(Double number, Double expectedResult, String message) {
        double result = calculator.ctg(number);
        Assert.assertEquals(result, expectedResult, 0.0000001, message);
    }

    @DataProvider(name = "valuesForCtgMethodTest")
    public Object[][] valuesForCtgMethodTest() {
        return new Object[][]{
                {new Double(180), new Double(-8165619), "Invalid result of cotangent from 180"},
                {new Double(90), new Double(0), "Invalid result of cotangent from 90"},
                {new Double(45), new Double(1), "Invalid result of cotangent from 45"},
                {new Double(5), new Double(11.43005), "Invalid result of cotangent from 5"},
                {new Double(1), new Double(57.28996), "Invalid result of cotangent from 1"},
                {new Double(0), new Double(Double.NaN), "Invalid result of cotangent from 0"},
                {new Double(-1), new Double(-57.28996), "Invalid result of cotangent from -1"},
                {new Double(-30.3), new Double(-1.711294), "Invalid result of cotangent from -30.3"},
                {new Double(-45), new Double(-1), "Invalid result of cotangent from -45"},
                {new Double(-90), new Double(0), "Invalid result of cotangent from -90"},
                {new Double(-180), new Double(8165619), "Invalid result of cotangent from -180"}
        };
    }
}
