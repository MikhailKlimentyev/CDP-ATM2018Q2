/**
 * TgMethodTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 6/27/2018
 */

package com.epam.cdp.atm2018q2.calc.testng.tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TgMethodTest extends BaseTest {

    @Test(dataProvider = "valuesForTgMethodTest")
    public void testTgWhenTgGetNumberThenReturnTangentFromIt(Double number, Double expectedResult, String message) {
        double result = calculator.tg(number);
        Assert.assertEquals(result, expectedResult, 0.0000001, message);
    }

    @DataProvider(name = "valuesForTgMethodTest")
    public Object[][] valuesForTgMethodTest() {
        return new Object[][]{
                {new Double(180), new Double(0), "Invalid result of Tangent from 180"},
                {new Double(90), new Double(16331239353195370.0), "Invalid result of Tangent from 90"},
                {new Double(45), new Double(1), "Invalid result of Tangent from 45"},
                {new Double(23.8), new Double(0.441052551858), "Invalid result of Tangent from 45"},
                {new Double(5), new Double(0.087488663526), "Invalid result of Tangent from 5"},
                {new Double(1), new Double(0.017455064928), "Invalid result of Tangent from 1"},
                {new Double(0), new Double(0), "Invalid result of Tangent from 0"},
                {new Double(-1), new Double(-0.017455064928), "Invalid result of Tangent from -1"},
                {new Double(-30.3), new Double(-0.584352818891), "Invalid result of Tangent from -30.3"},
                {new Double(-45), new Double(-1), "Invalid result of Tangent from -45"},
                {new Double(-90), new Double(-16331239353195370.0), "Invalid result of Tangent from -90"},
                {new Double(-180), new Double(0), "Invalid result of Tangent from -180"}
        };
    }
}
