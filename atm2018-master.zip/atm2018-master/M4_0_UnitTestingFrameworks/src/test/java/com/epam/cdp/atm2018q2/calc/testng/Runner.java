/**
 * Runner.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 6/24/2018
 */

package com.epam.cdp.atm2018q2.calc.testng;

import com.epam.cdp.atm2018q2.calc.testng.listeners.TestListeners;
import org.testng.ITestNGListener;
import org.testng.TestNG;
import org.testng.xml.XmlSuite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Runner {

    public static void main(String[] args) {
        TestNG testNg = new TestNG();
        TestListeners testListeners = new TestListeners();
        testNg.addListener((ITestNGListener)testListeners);

        XmlSuite suite = new XmlSuite();
        suite.setSuiteFiles(Arrays.asList("..\\atm2018\\M4_0_UnitTestingFrameworks\\src\\test\\java\\resources\\testng.xml"));

        List<XmlSuite> suites = new ArrayList();
        suites.add(suite);

        testNg.setXmlSuites(suites);
        testNg.run();
    }

}
