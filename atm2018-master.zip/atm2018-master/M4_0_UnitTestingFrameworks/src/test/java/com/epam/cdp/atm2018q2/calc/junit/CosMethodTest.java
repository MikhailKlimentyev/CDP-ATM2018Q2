/**
 * CosMethodTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 6/24/2018
 */

package com.epam.cdp.atm2018q2.calc.junit;

import com.epam.tat.module4.Calculator;
import org.junit.*;

public class CosMethodTest {

    private Calculator calculator;

    @Before
    public void setUp() {
        calculator = new Calculator();
    }

    @Test
    public void testCosWhenCosGetPositiveNumberThenReturnCosineFromIt() {
        double result = calculator.cos(35);
        Assert.assertEquals("Invalid Сosine result from Positive Number", 0.8191520, result, 0.0000001);
    }

    @Test
    public void testCosWhenGetFractionalNumberThenReturnCosineFromIt() {
        double result = calculator.cos(2.5);
        Assert.assertEquals("Invalid Сosine result from Fractional Number", 0.9990482, result, 0.0000001);
    }

    @Test
    public void testCosWhenCosGetZeroThenReturnOne() {
        double result = calculator.cos(0);
        Assert.assertEquals("Invalid Сosine result from Zero", 1, result, 0);
    }

    @Test
    public void testCosWhenCosGetOneThenReturnCosineFromOne() {
        double result = calculator.cos(1);
        Assert.assertEquals("Invalid Сosine result from One", 0.999847, result, 0.000001);
    }

    @Test
    public void testCosWhenCosGetNegativeNumberThenReturnCosineFromIt() {
        double result = calculator.cos(-1);
        Assert.assertEquals("Invalid Сosine result from Negative Number", 0.9998477, result, 0.0000001);
    }

    @After
    public void tearDown() {
        calculator = null;
    }
}
