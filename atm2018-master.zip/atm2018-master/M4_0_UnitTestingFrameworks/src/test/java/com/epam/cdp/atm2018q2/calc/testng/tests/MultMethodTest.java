/**
 * MultMethodTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 6/25/2018
 */

package com.epam.cdp.atm2018q2.calc.testng.tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class MultMethodTest extends BaseTest {

    //test mult(double a, double b)
    @Test(groups="Positive Test", dataProvider = "valuesForMultMethodWithDoubleParametersTest")
    public void testMultWhenMultGetFirstDoubleAndSecondDoubleThenResultOfMultiplicationIsDouble(Double firstNumber, Double secondNumber,
                                                                                        Double expectedResult, String message) {
        double result = calculator.mult(firstNumber, secondNumber);
        Assert.assertEquals(result, expectedResult, 0.0001, message);
    }

    @DataProvider(name = "valuesForMultMethodWithDoubleParametersTest")
    public Object[][] valuesForMultMethodWithDoubleParametersTest() {
        return new Object[][]{
                {new Double("1.0"), new Double("3.0"), new Double("3.0"), "Invalid result of 1.0 * 3.0"},
                {new Double(3.0), new Double(1.0), new Double(3.0), "Invalid result of 1.0 * 3.0"},
                {new Double(-3.0), new Double(1.0), new Double(-3.0), "Invalid result of -3.0 * 1.0"},
                {new Double(3.0), new Double(-1.0), new Double(-3.0), "Invalid result of 3.0 * -1.0"},
                {new Double(-3.0), new Double(-1.0), new Double(3.0), "Invalid result of -3.0 * -1.0"},
                {new Double(1000), new Double(7.0), new Double(7000.0), "Invalid result of 1000 * 7.0"},
                {new Double(0), new Double(5), new Double(0), "Invalid result of 0 * 5"},
                {new Double(0), new Double(0), new Double(0), "Invalid result of 0 * 0"},
                {new Double(854.3564), new Double(85.365), new Double(72932.1426), "Invalid result of 854.3564 * 85.365"},
                {new Double(13.0), new Double(7.65), new Double(99.45), "Invalid result of 13.0 * 7.65"},
                {new Double(13), new Double(7), new Double(91), "Invalid result of 13 * 7"},
                {new Double(7.5), new Double(6.3), new Double(47.25), "Invalid result of 7.5 * 6.3"},
                {new Double(0.0), new Double(0.0), new Double(0.0), "Invalid result of 0.0 * 0.0"}
        };
    }

    //test mult(long a, long b)
    @Test(groups="Positive Test", dataProvider = "valuesForMultMethodWithLongParametersTest")
    public void testMultWhenMultGetFirstLongAndSecondLongThenResultOfMultiplicationIsLong(Long firstNumber, Long secondNumber,
                                                                                          Long expectedResult, String message) {
        double result = calculator.mult(firstNumber, secondNumber);
        Assert.assertEquals(result, expectedResult, 0, message);
    }

    @DataProvider(name = "valuesForMultMethodWithLongParametersTest")
    public Object[][] valuesForMultMethodWithLongParametersTest() {
        return new Object[][]{
                {new Long("1"), new Long("3"), new Long("3"), "Invalid result of 1 * 3"},
                {new Long(3), new Long(1), new Long(3), "Invalid result of 1 * 3"},
                {new Long(-3), new Long(1), new Long(-3), "Invalid result of -3 * 1"},
                {new Long(3), new Long(-1), new Long(-3), "Invalid result of 3 * -1"},
                {new Long(-3), new Long(-1), new Long(3), "Invalid result of -3 * -1"},
                {new Long(1000), new Long(7), new Long(7000), "Invalid result of 1000 * 7"},
                {new Long(0), new Long(5), new Long(0), "Invalid result of 0 * 5"},
                {new Long(0), new Long(0), new Long(0), "Invalid result of 0 * 0"},
                {new Long(13), new Long(7), new Long(91), "Invalid result of 13 * 7"},
                {new Long(0), new Long(0), new Long(0), "Invalid result of 0 * 0"}
        };
    }
}
