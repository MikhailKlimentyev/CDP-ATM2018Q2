/**
 * SqrtMethodTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 6/29/2018
 */

package com.epam.cdp.atm2018q2.calc.testng.tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class SqrtMethodTest extends BaseTest {

    @Test(expectedExceptions = java.lang.IllegalArgumentException.class)
    public void testSqrtWhenSqrtGetNegativeNumberThenReturnException() {
        double result = calculator.sqrt(-5);
    }

    @Test(dataProvider = "valuesForSqrtMethodTest")
    public void testSqrtWhenSqrtGetNumberThenReturnSquareRootOfNumber(Double number, Double expectedResult, String message) {
        double result = calculator.sqrt(number);
        Assert.assertEquals(result, expectedResult, 0.00001, message);
    }

    @DataProvider(name = "valuesForSqrtMethodTest")
    public Object[][] valuesForSqrtMethodTest() {
        return new Object[][]{
                {new Double(100500.0), new Double(317.01734968295), "Invalid Square root of 100500.0"},
                {new Double(49.0), new Double(7), "Invalid Square root of 49.0"},
                {new Double(45464.565775), new Double(213.22421479513), "Invalid Square root of 45464.565775"},
                {new Double(0.1), new Double(0.31622776601684), "Invalid Square root of 0.1"},
                {new Double(0.34664), new Double(0.588761411779), "Invalid Square root of 0.34664"},
                {new Double(0), new Double(0), "Invalid Square root of 0"}

        };
    }
}