/**
 * IsNegativeMethodTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 6/25/2018
 */

package com.epam.cdp.atm2018q2.calc.testng.tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class IsNegativeMethodTest extends BaseTest {

    @Test(groups = "Positive Test", dataProvider = "valuesForIsNegativeMethodTestTrue")
    public void testIsNegativeWhenIsNegativeGetLongThenIfItIsNegativeReturnTrue(Long number, String message) {
        boolean result = calculator.isNegative(number);
        Assert.assertTrue(result, message);
    }

    @DataProvider(name = "valuesForIsNegativeMethodTestTrue")
    public Object[][] valuesForIsNegativeMethodTestTrue() {
        return new Object[][]{
                {new Long(-1), "-1"},
                {new Long(-1000), "-1000"}
        };
    }

    @Test(groups = "Negative Test", dataProvider = "valuesForIsNegativeMethodTestFalse")
    public void testIsNegativeWhenIsNegativeGetLongThenIfItIsPositiveReturnFalse(Long number, String message) {
        boolean result = calculator.isNegative(number);
        Assert.assertFalse(result, message);
    }

    @DataProvider(name = "valuesForIsNegativeMethodTestFalse")
    public Object[][] valuesForIsNegativeMethodTestFalse() {
        return new Object[][]{
                {new Long(500), "500"},
                {new Long(0), "0"},
                {new Long(1), "1"}
        };
    }
}
