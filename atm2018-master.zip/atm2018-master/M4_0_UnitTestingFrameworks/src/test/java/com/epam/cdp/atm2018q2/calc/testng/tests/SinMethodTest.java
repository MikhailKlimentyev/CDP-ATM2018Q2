/**
 * SinMethodTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 6/29/2018
 */

package com.epam.cdp.atm2018q2.calc.testng.tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class SinMethodTest extends BaseTest {

    @Test(dataProvider = "valuesForSinMethodTest")
    public void testSinWhenSinGetNumberThenReturnSinusFromIt(Double number, Double expectedResult, String message) {
        double result = calculator.sin(number);
        Assert.assertEquals(result, expectedResult, 0.00001, message);
    }

    @DataProvider(name = "valuesForSinMethodTest")
    public Object[][] valuesForSinMethodTest() {
        return new Object[][]{
                {new Double(180), new Double(1.2246467), "Invalid result of Sinus from 180"},
                {new Double(90), new Double(1), "Invalid result of Sinus from 90"},
                {new Double(45), new Double(0.70710678118655), "Invalid result of Sinus from 45"},
                {new Double(23.8), new Double(0.40354529635239), "Invalid result of Sinus from 45"},
                {new Double(5), new Double(0.087155742747658), "Invalid result of Sinus from 5"},
                {new Double(1), new Double(0.017452406437284), "Invalid result of Sinus from 1"},
                {new Double(0), new Double(0), "Invalid result of Sinus from 0"},
                {new Double(-1), new Double(-0.017452406437284), "Invalid result of Sinus from -1"},
                {new Double(-30.3), new Double(-0.50452762381502), "Invalid result of Sinus from -30.3"},
                {new Double(-45), new Double(-0.70710678118655), "Invalid result of Sinus from -45"},
                {new Double(-90), new Double(-1), "Invalid result of Sinus from -90"},
                {new Double(-180), new Double(-1.22464679914), "Invalid result of Sinus from -180"}
        };
    }
}
