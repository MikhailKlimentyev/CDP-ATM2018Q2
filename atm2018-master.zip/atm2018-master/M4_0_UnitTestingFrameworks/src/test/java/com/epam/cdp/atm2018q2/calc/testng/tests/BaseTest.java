/**
 * BaseTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 6/24/2018
 */

package com.epam.cdp.atm2018q2.calc.testng.tests;

import com.epam.tat.module4.Calculator;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class BaseTest {

    protected Calculator calculator;

    @BeforeClass (groups={"Positive Test", "Negative Test"})
    public void setUp() {
        calculator = new Calculator();
    }

    @AfterClass (groups={"Positive Test", "Negative Test"})
    public void tearDown() {
        calculator = null;
    }

}
