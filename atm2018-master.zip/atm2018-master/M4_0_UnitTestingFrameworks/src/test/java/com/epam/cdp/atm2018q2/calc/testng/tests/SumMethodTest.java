/**
 * SubMethodTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 6/25/2018
 */

package com.epam.cdp.atm2018q2.calc.testng.tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class SumMethodTest extends BaseTest {

    //test sub(double a, double b)
    @Test(groups="Positive Test", dataProvider = "valuesForSumMethodWithDoubleParametersTest")
    public void testSumWhenSumGetFirstDoubleAndSecondDoubleThenResultOfSumIsDouble(Double firstNumber, Double secondNumber,
                                                                                                Double expectedResult, String message) {
        double result = calculator.sum(firstNumber, secondNumber);
        Assert.assertEquals(result, expectedResult, 0.0001, message);
    }

    @DataProvider(name = "valuesForSumMethodWithDoubleParametersTest")
    public Object[][] valuesForSubMethodWithDoubleParametersTest() {
        return new Object[][]{
                {new Double("1.0"), new Double("3.0"), new Double("4.0"), "Invalid result of 1.0 + 3.0"},
                {new Double(3.0), new Double(1.0), new Double(4.0), "Invalid result of 3.0 + 1.0"},
                {new Double(-3.0), new Double(1.0), new Double(-2.0), "Invalid result of -3.0 + 1.0"},
                {new Double(3.0), new Double(-1.0), new Double(2.0), "Invalid result of 3.0 + -1.0"},
                {new Double(-3.0), new Double(-1.0), new Double(-4.0), "Invalid result of -3.0 + -1.0"},
                {new Double(1000), new Double(7.0), new Double(1007.0), "Invalid result of 1000 + 7.0"},
                {new Double(0), new Double(5), new Double(5.0), "Invalid result of 0 + 5"},
                {new Double(854.3564), new Double(85.365), new Double(939.7214), "Invalid result of 854.3564 + 85.365"},
                {new Double(13.0), new Double(7.65), new Double(20.65), "Invalid result of 13.0 + 7.65"},
                {new Double(13), new Double(7), new Double(20), "Invalid result of 13 + 7"},
                {new Double(7.5), new Double(6.3), new Double(13.8), "Invalid result of 7.5 + 6.3"},
                {new Double(0), new Double(0), new Double(0), "Invalid result of 0 + 0"},
                {new Double(-5), new Double(0), new Double(-5), "Invalid result of -5 + 0"},
        };
    }

    //test sub(long a, long b)
    @Test(groups="Positive Test", dataProvider = "valuesForSumMethodWithLongParametersTest")
    public void testSumWhenSumGetFirstLongAndSecondLongThenResultOfSumIsLong(Long firstNumber, Long secondNumber,
                                                                                     Long expectedResult, String message) {
        double result = calculator.sum(firstNumber, secondNumber);
        Assert.assertEquals(result, expectedResult, 0, message);
    }

    @DataProvider(name = "valuesForSumMethodWithLongParametersTest")
    public Object[][] valuesForSumMethodWithLongParametersTest() {
        return new Object[][]{
                {new Long("1"), new Long("3"), new Long("4"), "Invalid result of 1 + 3"},
                {new Long(3), new Long(1), new Long(4), "Invalid result of 3 + 1"},
                {new Long(-3), new Long(1), new Long(-2), "Invalid result of -3 + 1"},
                {new Long(3), new Long(-1), new Long(2), "Invalid result of 3 + -1"},
                {new Long(-3), new Long(-1), new Long(-4), "Invalid result of -3 + -1"},
                {new Long(1000), new Long(7), new Long(1007), "Invalid result of 1000 + 7"},
                {new Long(0), new Long(5), new Long(5), "Invalid result of 0 + 5"},
                {new Long(13), new Long(7), new Long(20), "Invalid result of 13 + 7"},
                {new Long(0), new Long(0), new Long(0), "Invalid result of 0 + 0"},
                {new Long(-5), new Long(0), new Long(-5), "Invalid result of -5 + 0"}
        };
    }
}
