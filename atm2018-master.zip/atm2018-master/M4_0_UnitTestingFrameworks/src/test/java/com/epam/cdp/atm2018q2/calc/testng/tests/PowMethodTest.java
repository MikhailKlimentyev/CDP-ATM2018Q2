/**
 * CtgMethodTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 6/24/2018
 */

package com.epam.cdp.atm2018q2.calc.testng.tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class PowMethodTest extends BaseTest {

    @Test(dataProvider = "valuesForPowMethodTest")
    public void testPowWhenPowGetFirstNumberAndSecondNumberThenReturnFirstNumberInPowerEqualsSecondNumber(Double firstNumber, Double secondNumber,
                                                                                                          Double expectedResult, String message) {
        double result = calculator.pow(firstNumber, secondNumber);
        Assert.assertEquals(result, expectedResult, 0.00001, message);
    }

    @DataProvider(name = "valuesForPowMethodTest")
    public Object[][] valuesForPowMethodTest() {
        return new Object[][]{
                {new Double(23.0), new Double(3.0), new Double(12167.0), "Invalid result of 23 to the power of 3"},
                {new Double(17.3), new Double(13), new Double(12433670115320000.0), "Invalid result of 17.3 to the power of 13"},
                {new Double(7.0), new Double(8.7), new Double(22508831.398886), "Invalid result of 7 to the power of 8.7"},
                {new Double(13.0), new Double(1.0), new Double(13.0), "Invalid result of 13 to the power of 1"},
                {new Double(1.0), new Double(37.0), new Double(1.0), "Invalid result of 1 to the power of 37"},
                {new Double(0.0), new Double(8.0), new Double(0.0), "Invalid result of 0 to the power of 8"},
                {new Double(0.0), new Double(0.0), new Double(1.0), "Invalid result of 0 to the power of 0"},
                {new Double(67.0), new Double(0.0), new Double(1.0), "Invalid result of 67 to the power of 0"},
                {new Double(63.0), new Double(-4.0), new Double(0.0), "Invalid result of 63 to the power of 4"},
                {new Double(-0.1), new Double(14.0), new Double(0.0), "Invalid result of -0.1 to the power of 14"},
                {new Double(-5.0), new Double(-2), new Double(0.04), "Invalid result of -5 to the power of -2"}
        };
    }
}
