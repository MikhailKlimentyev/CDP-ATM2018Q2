/**
 * GMailTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 7/2/2018
 */
package com.epam.cdp.atm2018q2.m05;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.util.concurrent.TimeUnit.SECONDS;

public class GMailTest {

    private WebDriver driver;

    //Web driver home
    private static final String WEBDRIVER_CHROME_DRIVER = "src\\main\\resources\\chromedriver.exe";

    //URL
    private static final String GMAIL_URL = "https://mail.google.com";

    //Credentials
    private static final String LOGIN = "foratm2018q@gmail.com";
    private static final String PASSWORD = "atm2018q";

    //Text for Inputs
    private static final String TEXT_OF_TO_INPUT_OF_EMAIL = "Mikhail Klimentsyev";
    private static final String TEXT_OF_SUBJECT_INPUT_OF_EMAIL = "Text to test subject input";
    private static final String TEXT_OF_BODY_INPUT_OF_EMAIL = "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. " + "Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, " + "nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat " + "massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, " + "imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. " + "Vivamus elementum semper nisi. \n\n" + "Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, " + "consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. " + "Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. " + "Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, " + "sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, " + "hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. \n\n" + "Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. " + "Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc.\n\n\n\n" + "Best Regards,\n\n" + "Mikhail Klimentsyeu\n" + "Software Testing Engineer";

    //Selectors
    private static final String LOGIN_INPUT = "//input[@type='email'][@class='whsOnd zHQkBf'][@autocomplete='username']";
    private static final String PASSWORD_INPUT = "//input[@type='password'][@name='password']";
    private static final String NEXT_BUTTON_ON_LOGIN_PAGE = "//div[@id='identifierNext'][@role='button']";
    private static final String NEXT_BUTTON_ON_PASSWORD_PAGE = "//div[@id='passwordNext']";
    private static final String ACCOUNT_ICON = "//a[@class='gb_b gb_db gb_R'][@role='button']";
    private static final String EMAIL_ON_ACCOUNT_ICON = "//div [@class='gb_yb']/div[@class='gb_Db']";
    private static final String COMPOSE_BUTTON = "//div[@class='T-I J-J5-Ji T-I-KE L3'][@role='button']";
    private static final String POP_OUT_BUTTON = "//table[@class='cf Ht']/tbody/tr/td[@class='Hm']/img[@class='Hq aUG']";
    private static final String TO_INPUT_OF_EMAIL = "//div[@class='wO nr l1']/textarea[@class='vO'][@role='combobox']";
    private static final String SUBJECT_INPUT_OF_EMAIL = "//div[@class='aoD az6']/input[@name='subjectbox'][@class='aoT']";
    private static final String BODY_INPUT_OF_EMAIL = "//div[@class='Am Al editable LW-avf'][@role='textbox']";
    private static final String CLOSE_BUTTON = "//img[@class='Ha'][@alt='Close']";
    private static final String INBOX_ICON = "//a[@class='J-Ke n0'][contains(text(), 'Inbox')]";
    private static final String DRAFTS_ICON = "//a[@class='J-Ke n0'][contains(text(), 'Drafts')]";
    private static final String DRAFT_EMAIL_CHECKBOX = "//div[@class='ae4 UI']/div[@class='Cp']/div/table[@class='F cf zt']/tbody/tr[@class='zA yO']/td[@class='oZ-x3 xY']/div/div[1]";
    private static final String DRAFT_LABEL = "//div[@class='yW']/font[text()='Draft']";
    private static final String TO_INPUT_OF_DRAFTED_EMAIL = "//div[@class='oL aDm az9']/span";
    private static final String SUBJECT_INPUT_OF_DRAFTED_EMAIL = "//form[@class='bAs']//input[@name='subject']";
    private static final String BODY_INPUT_OF_DRAFTED_EMAIL = "//div[@class='Am Al editable LW-avf']";
    private static final String HEADER_INPUT_OF_DRAFTED_EMAIL = "//div[@class='Hp']/h2[@class='a3E']/div[@class='aYF']";
    private static final String SEND_BUTTON = "//div[@class='J-J5-Ji btA']/div[@role='button'][text()='Send']";
    private static final String SENT_MAIL = "//a[@class='J-Ke n0'][contains(text(), 'Sent Mail')]";
    private static final String HEADER_OF_SENT_MAIL = "//div[1][@class='y6']/span[@class='bog']";
    private static final String SIGN_OUT_BUTTON = "//a[@id='gb_71'][text()='Sign out']";
    private static final String SIGN_OUT_CONFIRMATION = "//h1[@id='headingText']";

    //Web Elements
    private WebElement loginInput;
    private WebElement nextButtonOnLoginPage;
    private WebElement passwordInput;
    private WebElement nextButtonOnPasswordPage;
    private WebElement accountIcon;
    private List<WebElement> elementsToBeFound;
    private WebElement composeButton;
    private WebElement popOutButton;
    private WebElement toInputOfEmail;
    private WebElement subjectInputOfEmail;
    private WebElement bodyInputOfEmail;
    private WebElement closeButton;
    private WebElement inboxIcon;
    private WebElement draftsIcon;
    private WebElement checkboxInSentMailFolder;
    private WebElement binButtonInSentMailFolder;
    private int initialDraftsEmailCount;
    private int finalDraftsEmailCount;
    private WebElement signOutButton;
    private WebElement draftEmailCheckbox;
    private WebElement draftLabel;
    private WebElement toInputOfDraftedEmail;
    private WebElement subjectInputOfDraftedEmail;
    private WebElement bodyInputOfDraftedEmail;
    private WebElement headerInputOfDraftedEmail;
    private WebElement sendButton;
    private WebElement sentMail;
    private WebElement headerOfSentMail;
    WebElement confirmDeletionButton;
    WebElement SignOutButton;


    private static final String BIN_BUTTON_IN_SENT_MAIL_FOLDER = "//td[@class='oZ-x3 xY']/div[@role='checkbox']/div[@class='T-Jo-auh']";

    @BeforeClass(description = "Start Chrome browser, add Implicitly Wait")
    public void startBrowser() {
        System.setProperty("webdriver.chrome.driver", WEBDRIVER_CHROME_DRIVER);
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, SECONDS);
    }

//    @AfterClass(description = "Stop Chrome browser, webriver equals null")
//    public void stopBrowser() {
//        driver.quit();
//        driver = null;
//    }

    @Test(description = "Login to gmail.com")
    public void authTest() {
        openGmailUrl();
        doLogin(loginInput, nextButtonOnLoginPage, passwordInput, nextButtonOnPasswordPage);
        openAccountIcon(accountIcon);
        Assert.assertTrue(isElementPresent(elementsToBeFound, By.xpath(EMAIL_ON_ACCOUNT_ICON)), "Email label was not found. There is no email address on the account icon.");
        Assert.assertTrue(isElementPresent(elementsToBeFound, By.xpath(SIGN_OUT_BUTTON)), "'Sign out' button was not found. There is no email address on the account icon.");
    }

    @Test(description = "Compose Email, close Email without sending, verify that composed email presents in drafts folder", dependsOnMethods = "authTest")
    public void composeEmailTest() throws InterruptedException {
        int initialDraftsNumber = draftsNumber(draftsIcon);
        System.out.println("initialDraftsNumber: " + initialDraftsNumber);
        composeEmail(composeButton, popOutButton, toInputOfEmail, subjectInputOfEmail, bodyInputOfEmail);
        closeEmailPopup(closeButton);
        int finalDraftsNumber = draftsNumber(draftsIcon);
        System.out.println("finalDraftsNumber: " + finalDraftsNumber);
        Assert.assertTrue(finalDraftsNumber == initialDraftsNumber + 1, "Email was not added to 'Drafts' folder");
    }

    @Test(description = "Compare content of composed and drafted emails", dependsOnMethods = "composeEmailTest")
    public void compareDraftedEmailContentTest() {
        openDraftsEmail(draftsIcon, draftEmailCheckbox, draftLabel);
        Assert.assertEquals(getTextFromToFieldOfDraftedEmail(toInputOfEmail), TEXT_OF_TO_INPUT_OF_EMAIL, "Text in 'To' field of drafted email is not valid");
        Assert.assertEquals(getTextFromSubjectFieldOfDraftedEmail(subjectInputOfDraftedEmail), TEXT_OF_SUBJECT_INPUT_OF_EMAIL, "Text in 'Subject' field of drafted email is not valid");
        Assert.assertEquals(getTextFromBodyFieldOfDraftedEmail(bodyInputOfDraftedEmail), TEXT_OF_BODY_INPUT_OF_EMAIL, "Text in 'Body' field of drafted email is not valid");
        Assert.assertEquals(getTextFromHeaderFieldOfDraftedEmail(headerInputOfDraftedEmail), TEXT_OF_SUBJECT_INPUT_OF_EMAIL, "Text of Header of drafted email is not valid");
    }

    @Test(description = "Send email, verify that the mail disappeared from ‘Drafts’ folder, verify that the mail is in ‘Sent’ folder.", dependsOnMethods = "compareDraftedEmailContentTest")
    public void sendEmailTest() throws InterruptedException {
        int initialDraftsNumber = draftsNumber(draftsIcon);
        clickOnSendButton(sendButton);
        Thread.sleep(1000);
        int finalDraftsNumber = draftsNumber(draftsIcon);
        Assert.assertEquals(finalDraftsNumber, initialDraftsNumber - 1, "Sent was not deleted from 'Drafts' folder");
        Assert.assertEquals(getSubjectOfLastSentEmail(sentMail, headerOfSentMail), TEXT_OF_SUBJECT_INPUT_OF_EMAIL, "Email was not sent");
    }

    @Test(description = "Log out", dependsOnMethods = "sendEmailTest")
    public void doLogOutTest() throws InterruptedException {
        doSignOut(signOutButton);
        Assert.assertTrue(isElementPresent(elementsToBeFound, By.xpath(SIGN_OUT_CONFIRMATION)), "Sign out was not made");
    }

    public void doSignOut(WebElement signOutButton) throws InterruptedException {
        accountIcon = driver.findElement(By.xpath(ACCOUNT_ICON));
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("arguments[0].click();", accountIcon);
        WebDriverWait wait = new WebDriverWait(driver, 20);
        signOutButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SIGN_OUT_BUTTON)));
        Thread.sleep(1000);
        signOutButton.click();
        if (isAlertPresent()) {
            Alert logOutConfirmation = driver.switchTo().alert();
            logOutConfirmation.accept();
        }
    }

    public void doLogin(WebElement loginInput, WebElement nextButtonOnLoginPage, WebElement passwordInput, WebElement nextButtonOnPasswordPage) {
        loginInput = driver.findElement(By.xpath(LOGIN_INPUT));
        loginInput.sendKeys(LOGIN);

        nextButtonOnLoginPage = driver.findElement(By.xpath(NEXT_BUTTON_ON_LOGIN_PAGE));
        nextButtonOnLoginPage.click();

        passwordInput = driver.findElement(By.xpath(PASSWORD_INPUT));
        passwordInput.sendKeys(PASSWORD);

        nextButtonOnPasswordPage = driver.findElement(By.xpath(NEXT_BUTTON_ON_PASSWORD_PAGE));
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("arguments[0].click();", nextButtonOnPasswordPage);
    }

    public void openGmailUrl() {
        driver.get(GMAIL_URL);
    }

    public void openAccountIcon(WebElement accountIcon) {
        accountIcon = driver.findElement(By.xpath(ACCOUNT_ICON));
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("arguments[0].click();", accountIcon);
    }

    private boolean isElementPresent(List<WebElement> elementsToBeFound, By by) {
        elementsToBeFound = driver.findElements(by);
        if (elementsToBeFound.size() != 0) {
            return true;
        } else {
            return false;
        }
    }

    public void composeEmail(WebElement composeButton, WebElement popOutButton, WebElement toInputOfEmail, WebElement subjectInputOfEmail, WebElement bodyInputOfEmail) {
        composeButton = driver.findElement(By.xpath(COMPOSE_BUTTON));
        composeButton.click();

        //Pop out email popup
        popOutButton = (new WebDriverWait(driver, 30)).
                until(ExpectedConditions.presenceOfElementLocated(By.xpath(POP_OUT_BUTTON)));
        popOutButton.click();

        toInputOfEmail = (new WebDriverWait(driver, 30)).
                until(ExpectedConditions.presenceOfElementLocated(By.xpath(TO_INPUT_OF_EMAIL)));
        toInputOfEmail.sendKeys(LOGIN, Keys.RETURN);

        subjectInputOfEmail = (new WebDriverWait(driver, 30)).
                until(ExpectedConditions.presenceOfElementLocated(By.xpath(SUBJECT_INPUT_OF_EMAIL)));
        subjectInputOfEmail.sendKeys(TEXT_OF_SUBJECT_INPUT_OF_EMAIL);

        bodyInputOfEmail = driver.findElement(By.xpath(BODY_INPUT_OF_EMAIL));
        bodyInputOfEmail.sendKeys(TEXT_OF_BODY_INPUT_OF_EMAIL);
    }

    public void closeEmailPopup(WebElement closeButton) {
        closeButton = (new WebDriverWait(driver, 20)).
                until(ExpectedConditions.visibilityOfElementLocated(By.xpath(CLOSE_BUTTON)));
        closeButton.click();
    }

    public int draftsNumber(WebElement draftsIcon) {
        draftsIcon = driver.findElement(By.xpath(DRAFTS_ICON));
        String draftsIconText = draftsIcon.getText();
        Pattern pattern = Pattern.compile("\\d+");
        Matcher matcher = pattern.matcher(draftsIconText);
        int draftsNumber = 0;
        while (matcher.find()) {
            String draftsIconNumber = draftsIconText.substring(matcher.start(), matcher.end());
            draftsNumber = Integer.parseInt(draftsIconNumber);
        }
        return draftsNumber;
    }

    public String getTextFromToFieldOfDraftedEmail(WebElement toInputOfDraftedEmail) {
        toInputOfDraftedEmail = driver.findElement(By.xpath(TO_INPUT_OF_DRAFTED_EMAIL));
        return toInputOfDraftedEmail.getText();
    }

    public String getTextFromSubjectFieldOfDraftedEmail(WebElement subjectInputOfDraftedEmail) {
        subjectInputOfDraftedEmail = driver.findElement(By.xpath(SUBJECT_INPUT_OF_DRAFTED_EMAIL));
        return subjectInputOfDraftedEmail.getAttribute("value");
    }

    public String getTextFromBodyFieldOfDraftedEmail(WebElement bodyInputOfDraftedEmail) {
        bodyInputOfDraftedEmail = driver.findElement(By.xpath(BODY_INPUT_OF_DRAFTED_EMAIL));
        return bodyInputOfDraftedEmail.getText();
    }

    public String getTextFromHeaderFieldOfDraftedEmail(WebElement headerInputOfDraftedEmail) {
        headerInputOfDraftedEmail = driver.findElement(By.xpath(HEADER_INPUT_OF_DRAFTED_EMAIL));
        return headerInputOfDraftedEmail.getText();
    }

    public void openDraftsEmail(WebElement draftsIcon, WebElement draftEmail, WebElement draftLabel) {
        draftsIcon = driver.findElement(By.xpath(DRAFTS_ICON));
        draftsIcon.click();
        draftLabel = driver.findElement(By.xpath(DRAFT_LABEL));
        if ((draftLabel.getText().equals("Draft"))) {
            draftEmailCheckbox = driver.findElement(By.xpath(DRAFT_EMAIL_CHECKBOX));
            draftEmailCheckbox.click();
            draftLabel.click();
        }
    }

    public String getSubjectOfLastSentEmail(WebElement sentMail, WebElement headerOfSentMail) {
        sentMail = driver.findElement(By.xpath(SENT_MAIL));
        sentMail.click();
        headerOfSentMail = driver.findElement(By.xpath(HEADER_OF_SENT_MAIL));
        return headerOfSentMail.getAttribute("textContent");
    }

    public void clickOnSendButton(WebElement sendButton) {
        sendButton = driver.findElement(By.xpath(SEND_BUTTON));
        sendButton.click();
    }

    public boolean isAlertPresent() {
        try {
            driver.switchTo().alert();
            return true;
        } catch (NoAlertPresentException Ex) {
            return false;
        }
    }

//   public void deleteSentEmail(WebElement sentMail, WebElement checkboxInSentMailFolder, WebElement confirmDeletionButton) throws InterruptedException {
//        sentMail = driver.findElement(By.xpath(SENT_MAIL));
//        sentMail.click();
//        checkboxInSentMailFolder = driver.findElement(By.xpath("//body[@class='aAU']/div[@style='position: relative; min-height: 100%;']/div[@class='nH']/div[@class='nH']/div[@class='nH bkL']/div/div[@class='nH bkK nn']/div/div/div/div/div[@class='AO']/div[@class='Tm aeJ']/div[@class='aeF']/div[@class='nH']/div[@class='BltHke nH oy8Mbf aE3']/div[@class='UI']/div/div[@class='ae4 aDM']/div[@class='Cp']/div/table/tbody/tr[1]/td[@class='oZ-x3 xY']/div[@role='checkbox']/div[1]"));
//        JavascriptExecutor executor = (JavascriptExecutor) driver;
//        executor.executeScript("arguments[0].contextClick();", checkboxInSentMailFolder);
//        Actions rightClickAction = new Actions(driver).contextClick(checkboxInSentMailFolder);
//        rightClickAction.sendKeys(Keys.ARROW_UP).sendKeys(Keys.RETURN).build().perform();
//        confirmDeletionButton = driver.findElement(By.xpath("//div[@class='Kj-JD-Jl']/button[@name='ok'][@class='J-at1-auR J-at1-atl']"));
//        confirmDeletionButton.click();
//    }

//    Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(30)).pollingEvery(Duration.ofMillis(1000)).ignoring(NoSuchElementException.class);
//    WebElement clickseleniumlink = wait.until(new Function<WebDriver, WebElement>() {
//
//        public WebElement apply(WebDriver driver) {
//            return driver.findElement(By.xpath("//a[@class='gb_Ea gb_1f gb_8f gb_Oe gb_Jb'][text()='Sign out']"));
//        }
//    });

}
