/**
 * Company.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 8/26/2018
 */

package com.epam.cdp.atm2018q2.m11.objects;

public class Company {
}
