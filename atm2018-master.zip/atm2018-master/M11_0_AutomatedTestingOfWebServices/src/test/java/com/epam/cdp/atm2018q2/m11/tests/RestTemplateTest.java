/**
 * RestTemplateTest.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 8/26/2018
 */

package com.epam.cdp.atm2018q2.m11.tests;

import com.epam.cdp.atm2018q2.m11.objects.User;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.testng.Assert;
import org.testng.annotations.Test;

public class RestTemplateTest {

    @Test
    public void checkStatusCode() {
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<User[]> response = restTemplate.getForEntity("https://jsonplaceholder.typicode.com/users", User[].class);
        int actualStatusCode = response.getStatusCode().value();
        System.out.println("actualStatusCode: " + actualStatusCode);
        Assert.assertEquals(actualStatusCode, 200);
    }

    @Test
    public void checkResponseHeader() {
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<User[]> response = restTemplate.getForEntity("https://jsonplaceholder.typicode.com/users", User[].class);
        HttpHeaders headers = response.getHeaders();
        String actualContentTypeValue = headers.getContentType().toString();
        System.out.println("actualContentTypeValue: " + actualContentTypeValue);
        Assert.assertEquals(actualContentTypeValue, "application/json;charset=utf-8");
    }

    @Test
    public void checkResponseBody() {
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<User[]> response = restTemplate.getForEntity("https://jsonplaceholder.typicode.com/users", User[].class);
        User[] actualUsers = response.getBody();
        Assert.assertEquals(actualUsers.length, 10);
    }
}
