/**
 * HttpClient.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 8/28/2018
 */

package com.epam.cdp.atm2018q2.m11.tests;

import com.epam.cdp.atm2018q2.m11.objects.User;
import com.google.gson.Gson;
import org.apache.http.Header;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;

public class HttpClient {
    @Test
    public void checkStatusCodeTest() {
        CloseableHttpClient httpclient = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet("https://jsonplaceholder.typicode.com/users");
        CloseableHttpResponse response = null;
        try {
            response = httpclient.execute(httpGet);
        } catch (IOException e) {
            e.printStackTrace();
        }
        int statusCodeAct = response.getStatusLine().getStatusCode();
        System.out.println(statusCodeAct);
        Assert.assertEquals(statusCodeAct, 200);
    }

    @Test
    public void checkResponseBodyViaDeserializationTest() {
        CloseableHttpClient httpclient = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet("https://jsonplaceholder.typicode.com/users");
        CloseableHttpResponse response = null;
        try {
            response = httpclient.execute(httpGet);
        } catch (IOException e) {
            e.printStackTrace();
        }
        String json = null;
        try {
            json = EntityUtils.toString(response.getEntity(), "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
        }
        Gson gson = new Gson();
        User[] users = gson.fromJson(json, User[].class);
        System.out.println(users[0].getName());
        Assert.assertEquals(users[0].getName(), "Leanne Graham");
    }

    @Test
    public void checkResponseHeaderTest() {
        CloseableHttpClient httpclient = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet("https://jsonplaceholder.typicode.com/users");
        CloseableHttpResponse response = null;
        try {
            response = httpclient.execute(httpGet);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Header[] contentTypeHeaders = response.getHeaders("Content-Type");
        System.out.println(contentTypeHeaders[0]);
        Assert.assertEquals(contentTypeHeaders[0].getValue(), "application/json; charset=utf-8");
    }
}


