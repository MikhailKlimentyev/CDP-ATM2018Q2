/**
 * @author Mikhail Klimentsyeu
 * @version 2.0
 * @since 02/24/2018
 */

package tasks.collections;