package tasks.model;

/**
 * Passable.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 03/09/2018
 */
public interface Passable {

    public void driveOffRoad();
}
