package tasks.model;

/**
 * Roomy.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 03/09/2018
 */
public interface Roomy {

    public void setAddedSeats();
}
