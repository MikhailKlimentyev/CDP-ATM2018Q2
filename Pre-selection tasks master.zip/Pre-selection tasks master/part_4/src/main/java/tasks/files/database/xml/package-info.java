/**
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 04/01/2018
 */
package tasks.files.database.xml;