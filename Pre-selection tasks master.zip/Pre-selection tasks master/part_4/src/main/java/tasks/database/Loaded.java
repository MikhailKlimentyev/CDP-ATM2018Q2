package tasks.database;

/**
 * Loaded.
 *
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 03/09/2018
 */
public interface Loaded {

    public void transportGoods();
}
