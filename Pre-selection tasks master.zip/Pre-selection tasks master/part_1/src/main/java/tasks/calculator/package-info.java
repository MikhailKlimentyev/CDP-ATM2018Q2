/**
 * @author Mikhail Klimentsyeu
 * @version 1.0
 * @since 02/10/2018
 */
package tasks.calculator;